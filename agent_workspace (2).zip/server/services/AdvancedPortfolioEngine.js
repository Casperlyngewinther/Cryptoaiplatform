const EventEmitter = require('events');

/**
 * Advanced Portfolio Analytics Engine
 * Provides sophisticated portfolio analysis, optimization, and insights
 */
class AdvancedPortfolioEngine extends EventEmitter {
  constructor() {
    super();
    this.portfolioHistory = [];
    this.benchmarks = new Map();
    this.riskMetrics = new Map();
    this.correlationMatrix = new Map();
    this.isInitialized = false;
  }

  async initialize() {
    console.log('🔄 Initializing Advanced Portfolio Engine...');
    
    // Initialize benchmarks
    await this.loadBenchmarks();
    
    // Start periodic analysis
    this.startPeriodicAnalysis();
    
    this.isInitialized = true;
    console.log('✅ Advanced Portfolio Engine initialized');
  }

  async loadBenchmarks() {
    // Load major crypto benchmarks
    this.benchmarks.set('BTC', { symbol: 'BTC', name: 'Bitcoin', weight: 1.0 });
    this.benchmarks.set('CRYPTO10', { 
      composition: {
        'BTC': 0.3, 'ETH': 0.2, 'BNB': 0.1, 'ADA': 0.1, 
        'SOL': 0.1, 'DOT': 0.05, 'AVAX': 0.05, 'LINK': 0.05, 
        'UNI': 0.03, 'MATIC': 0.02
      }
    });
  }

  /**
   * Comprehensive Portfolio Analysis
   */
  async analyzePortfolio(portfolioData) {
    const analysis = {
      timestamp: new Date().toISOString(),
      overview: await this.calculateOverview(portfolioData),
      riskMetrics: await this.calculateRiskMetrics(portfolioData),
      performance: await this.calculatePerformance(portfolioData),
      optimization: await this.optimizePortfolio(portfolioData),
      diversification: await this.analyzeDiversification(portfolioData),
      benchmarkComparison: await this.compareToBenchmarks(portfolioData),
      recommendations: await this.generateRecommendations(portfolioData)
    };

    this.emit('portfolioAnalyzed', analysis);
    return analysis;
  }

  async calculateOverview(portfolio) {
    const totalValue = portfolio.positions.reduce((sum, pos) => sum + pos.value, 0);
    const totalPnL = portfolio.positions.reduce((sum, pos) => sum + (pos.unrealizedPnL || 0), 0);
    const totalPnLPercent = totalValue > 0 ? (totalPnL / (totalValue - totalPnL)) * 100 : 0;

    return {
      totalValue: totalValue,
      totalPnL: totalPnL,
      totalPnLPercent: totalPnLPercent,
      positionCount: portfolio.positions.length,
      exchangeCount: new Set(portfolio.positions.map(p => p.exchange)).size,
      lastUpdated: new Date().toISOString()
    };
  }

  async calculateRiskMetrics(portfolio) {
    const returns = this.calculateReturns(portfolio);
    const volatility = this.calculateVolatility(returns);
    const var95 = this.calculateVaR(returns, 0.95);
    const cvar95 = this.calculateCVaR(returns, 0.95);
    const maxDrawdown = this.calculateMaxDrawdown(portfolio);
    const sharpeRatio = this.calculateSharpeRatio(returns, volatility);
    const calmarRatio = this.calculateCalmarRatio(returns, maxDrawdown);

    return {
      volatility: volatility,
      valueAtRisk95: var95,
      conditionalVaR95: cvar95,
      maxDrawdown: maxDrawdown,
      sharpeRatio: sharpeRatio,
      calmarRatio: calmarRatio,
      beta: await this.calculateBeta(portfolio),
      correlation: await this.calculateCorrelations(portfolio)
    };
  }

  async calculatePerformance(portfolio) {
    const timeframes = ['1d', '7d', '30d', '90d', '1y'];
    const performance = {};

    for (const timeframe of timeframes) {
      const period = this.getTimeframePeriod(timeframe);
      const historicalData = this.getHistoricalData(portfolio, period);
      
      performance[timeframe] = {
        return: this.calculatePeriodReturn(historicalData),
        volatility: this.calculatePeriodVolatility(historicalData),
        sharpe: this.calculatePeriodSharpe(historicalData),
        maxDrawdown: this.calculatePeriodMaxDrawdown(historicalData),
        winRate: this.calculateWinRate(historicalData),
        profitFactor: this.calculateProfitFactor(historicalData)
      };
    }

    return performance;
  }

  /**
   * Modern Portfolio Theory Optimization
   */
  async optimizePortfolio(portfolio) {
    const assets = portfolio.positions.map(p => p.symbol);
    const returns = await this.getAssetReturns(assets);
    const covariance = this.calculateCovarianceMatrix(returns);
    
    // Efficient Frontier Calculation
    const efficientFrontier = this.calculateEfficientFrontier(returns, covariance);
    
    // Optimal portfolios
    const minVariance = this.findMinimumVariancePortfolio(returns, covariance);
    const maxSharpe = this.findMaximumSharpePortfolio(returns, covariance);
    const equalWeight = this.calculateEqualWeightPortfolio(assets);

    return {
      currentAllocation: this.getCurrentAllocation(portfolio),
      recommendedAllocations: {
        minimumVariance: minVariance,
        maximumSharpe: maxSharpe,
        equalWeight: equalWeight
      },
      efficientFrontier: efficientFrontier,
      rebalanceRecommendations: this.generateRebalanceRecommendations(portfolio, maxSharpe)
    };
  }

  async analyzeDiversification(portfolio) {
    const assets = portfolio.positions;
    
    // Herfindahl-Hirschman Index (HHI)
    const weights = assets.map(a => a.value / portfolio.totalValue);
    const hhi = weights.reduce((sum, w) => sum + (w * w), 0);
    
    // Effective number of assets
    const effectiveAssets = 1 / hhi;
    
    // Sector diversification
    const sectorAnalysis = await this.analyzeSectorDiversification(assets);
    
    // Geographic diversification
    const geoAnalysis = await this.analyzeGeographicDiversification(assets);

    return {
      herfindahlIndex: hhi,
      effectiveNumberOfAssets: effectiveAssets,
      diversificationScore: Math.min(effectiveAssets / assets.length, 1.0),
      sectorDiversification: sectorAnalysis,
      geographicDiversification: geoAnalysis,
      concentrationRisk: this.calculateConcentrationRisk(assets)
    };
  }

  async compareToBenchmarks(portfolio) {
    const comparisons = {};
    
    for (const [benchmarkName, benchmark] of this.benchmarks) {
      const portfolioReturns = this.calculateReturns(portfolio);
      const benchmarkReturns = await this.getBenchmarkReturns(benchmark);
      
      comparisons[benchmarkName] = {
        tracking_error: this.calculateTrackingError(portfolioReturns, benchmarkReturns),
        information_ratio: this.calculateInformationRatio(portfolioReturns, benchmarkReturns),
        alpha: this.calculateAlpha(portfolioReturns, benchmarkReturns),
        beta: this.calculateBeta(portfolioReturns, benchmarkReturns),
        correlation: this.calculateCorrelation(portfolioReturns, benchmarkReturns),
        outperformance: this.calculateOutperformance(portfolioReturns, benchmarkReturns)
      };
    }

    return comparisons;
  }

  async generateRecommendations(portfolio) {
    const analysis = {
      riskLevel: this.assessRiskLevel(portfolio),
      diversificationNeeds: this.assessDiversificationNeeds(portfolio),
      rebalancingNeeds: this.assessRebalancingNeeds(portfolio)
    };

    const recommendations = [];

    // Risk-based recommendations
    if (analysis.riskLevel === 'HIGH') {
      recommendations.push({
        type: 'RISK_REDUCTION',
        priority: 'HIGH',
        action: 'Reduce position sizes in high-volatility assets',
        details: this.getHighRiskPositions(portfolio)
      });
    }

    // Diversification recommendations
    if (analysis.diversificationNeeds.score < 0.7) {
      recommendations.push({
        type: 'DIVERSIFICATION',
        priority: 'MEDIUM',
        action: 'Improve portfolio diversification',
        details: analysis.diversificationNeeds.suggestions
      });
    }

    // Rebalancing recommendations
    if (analysis.rebalancingNeeds.required) {
      recommendations.push({
        type: 'REBALANCING',
        priority: 'MEDIUM',
        action: 'Rebalance portfolio allocations',
        details: analysis.rebalancingNeeds.actions
      });
    }

    return {
      summary: `${recommendations.length} recommendations generated`,
      recommendations: recommendations,
      analysis: analysis
    };
  }

  /**
   * Utility Methods
   */
  calculateReturns(portfolio) {
    // Calculate historical returns from portfolio history
    if (this.portfolioHistory.length < 2) return [];
    
    const returns = [];
    for (let i = 1; i < this.portfolioHistory.length; i++) {
      const prevValue = this.portfolioHistory[i-1].totalValue;
      const currentValue = this.portfolioHistory[i].totalValue;
      returns.push((currentValue - prevValue) / prevValue);
    }
    return returns;
  }

  calculateVolatility(returns) {
    if (returns.length === 0) return 0;
    
    const mean = returns.reduce((sum, r) => sum + r, 0) / returns.length;
    const variance = returns.reduce((sum, r) => sum + Math.pow(r - mean, 2), 0) / returns.length;
    return Math.sqrt(variance) * Math.sqrt(252); // Annualized
  }

  calculateVaR(returns, confidence) {
    if (returns.length === 0) return 0;
    
    const sorted = returns.slice().sort((a, b) => a - b);
    const index = Math.floor((1 - confidence) * sorted.length);
    return sorted[index] || 0;
  }

  calculateCVaR(returns, confidence) {
    const var_value = this.calculateVaR(returns, confidence);
    const tail_losses = returns.filter(r => r <= var_value);
    
    if (tail_losses.length === 0) return 0;
    return tail_losses.reduce((sum, loss) => sum + loss, 0) / tail_losses.length;
  }

  calculateSharpeRatio(returns, volatility) {
    if (volatility === 0 || returns.length === 0) return 0;
    
    const meanReturn = returns.reduce((sum, r) => sum + r, 0) / returns.length;
    const riskFreeRate = 0.02; // 2% annual risk-free rate
    
    return (meanReturn * 252 - riskFreeRate) / volatility;
  }

  startPeriodicAnalysis() {
    // Run portfolio analysis every hour
    setInterval(async () => {
      if (this.portfolioHistory.length > 0) {
        const latest = this.portfolioHistory[this.portfolioHistory.length - 1];
        await this.analyzePortfolio(latest);
      }
    }, 60 * 60 * 1000); // 1 hour
  }

  addPortfolioSnapshot(portfolioData) {
    this.portfolioHistory.push({
      ...portfolioData,
      timestamp: new Date().toISOString()
    });

    // Keep only last 1000 snapshots
    if (this.portfolioHistory.length > 1000) {
      this.portfolioHistory = this.portfolioHistory.slice(-1000);
    }
  }

  getStatus() {
    return {
      isInitialized: this.isInitialized,
      portfolioSnapshots: this.portfolioHistory.length,
      benchmarksLoaded: this.benchmarks.size,
      lastAnalysis: this.portfolioHistory.length > 0 ? 
        this.portfolioHistory[this.portfolioHistory.length - 1].timestamp : null
    };
  }
}

module.exports = AdvancedPortfolioEngine;