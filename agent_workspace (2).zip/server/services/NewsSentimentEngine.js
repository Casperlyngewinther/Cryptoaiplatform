const EventEmitter = require('events');
const axios = require('axios');

/**
 * News & Sentiment Analysis Engine
 * Aggregates crypto news and performs sentiment analysis for trading insights
 */
class NewsSentimentEngine extends EventEmitter {
  constructor() {
    super();
    this.newsSources = new Map();
    this.articles = new Map();
    this.sentimentData = new Map();
    this.keywords = new Set();
    this.isInitialized = false;
  }

  async initialize() {
    console.log('🔄 Initializing News & Sentiment Engine...');
    
    // Setup news sources
    await this.setupNewsSources();
    
    // Initialize sentiment tracking
    await this.initializeSentimentTracking();
    
    // Start news aggregation
    this.startNewsAggregation();
    
    this.isInitialized = true;
    console.log('✅ News & Sentiment Engine initialized');
  }

  async setupNewsSources() {
    // Configure major crypto news sources
    this.newsSources.set('coindesk', {
      name: 'CoinDesk',
      url: 'https://www.coindesk.com',
      rss: 'https://www.coindesk.com/arc/outboundfeeds/rss/',
      api: null,
      credibility: 0.9,
      category: 'mainstream',
      enabled: true,
      lastFetch: null
    });

    this.newsSources.set('cointelegraph', {
      name: 'Cointelegraph',
      url: 'https://cointelegraph.com',
      rss: 'https://cointelegraph.com/rss',
      api: null,
      credibility: 0.85,
      category: 'mainstream',
      enabled: true,
      lastFetch: null
    });

    this.newsSources.set('cryptonews', {
      name: 'CryptoNews',
      url: 'https://cryptonews.com',
      rss: 'https://cryptonews.com/news/feed/',
      api: null,
      credibility: 0.8,
      category: 'mainstream',
      enabled: true,
      lastFetch: null
    });

    this.newsSources.set('decrypt', {
      name: 'Decrypt',
      url: 'https://decrypt.co',
      rss: 'https://decrypt.co/feed',
      api: null,
      credibility: 0.85,
      category: 'mainstream',
      enabled: true,
      lastFetch: null
    });

    this.newsSources.set('newsapi', {
      name: 'NewsAPI Crypto',
      url: 'https://newsapi.org',
      rss: null,
      api: 'https://newsapi.org/v2/everything',
      credibility: 0.75,
      category: 'aggregator',
      enabled: process.env.NEWSAPI_KEY ? true : false,
      lastFetch: null
    });

    // Social media sources for sentiment
    this.newsSources.set('twitter_sentiment', {
      name: 'Twitter Sentiment',
      url: 'https://twitter.com',
      api: 'https://api.twitter.com/2/tweets/search/recent',
      credibility: 0.6,
      category: 'social',
      enabled: process.env.TWITTER_BEARER_TOKEN ? true : false,
      lastFetch: null
    });

    this.newsSources.set('reddit_sentiment', {
      name: 'Reddit Crypto',
      url: 'https://reddit.com',
      api: 'https://www.reddit.com/r/cryptocurrency/hot.json',
      credibility: 0.65,
      category: 'social',
      enabled: true,
      lastFetch: null
    });

    console.log(`📰 Configured ${this.newsSources.size} news sources`);
  }

  async initializeSentimentTracking() {
    // Initialize sentiment tracking for major cryptocurrencies
    const symbols = ['BTC', 'ETH', 'BNB', 'ADA', 'SOL', 'DOT', 'LINK', 'UNI', 'AVAX', 'MATIC'];
    
    for (const symbol of symbols) {
      this.sentimentData.set(symbol, {
        symbol: symbol,
        sentiment: {
          score: 0, // -1 (very negative) to +1 (very positive)
          confidence: 0,
          trend: 'neutral',
          lastUpdate: new Date().toISOString()
        },
        metrics: {
          bullishMentions: 0,
          bearishMentions: 0,
          totalMentions: 0,
          influencerSentiment: 0,
          socialVolume: 0,
          fearGreedIndex: 50
        },
        sources: {
          news: 0,
          twitter: 0,
          reddit: 0,
          telegram: 0
        },
        keywords: new Set(),
        history: []
      });
    }

    // Initialize general market sentiment keywords
    this.keywords = new Set([
      // Bullish keywords
      'bull', 'bullish', 'moon', 'pump', 'rally', 'surge', 'breakout', 'resistance',
      'support', 'hodl', 'buy', 'accumulate', 'institutional', 'adoption',
      
      // Bearish keywords
      'bear', 'bearish', 'dump', 'crash', 'correction', 'sell', 'panic', 'fud',
      'regulation', 'ban', 'hack', 'scam', 'bubble', 'overvalued',
      
      // Neutral/Technical
      'analysis', 'technical', 'resistance', 'support', 'volume', 'chart',
      'pattern', 'indicator', 'signal', 'forecast', 'prediction'
    ]);
  }

  /**
   * Aggregate News from Multiple Sources
   */
  async aggregateNews(symbols = ['BTC', 'ETH'], limit = 50) {
    const aggregatedNews = [];
    
    try {
      // Fetch from RSS feeds
      for (const [sourceId, source] of this.newsSources) {
        if (!source.enabled || !source.rss) continue;
        
        try {
          const articles = await this.fetchRSSFeed(source, symbols, 20);
          aggregatedNews.push(...articles);
          
          source.lastFetch = new Date().toISOString();
          console.log(`📰 Fetched ${articles.length} articles from ${source.name}`);
          
        } catch (error) {
          console.error(`Error fetching from ${source.name}:`, error.message);
        }
      }

      // Fetch from APIs
      for (const [sourceId, source] of this.newsSources) {
        if (!source.enabled || !source.api) continue;
        
        try {
          const articles = await this.fetchAPINews(source, symbols, 15);
          aggregatedNews.push(...articles);
          
          source.lastFetch = new Date().toISOString();
          console.log(`📰 Fetched ${articles.length} articles from ${source.name} API`);
          
        } catch (error) {
          console.error(`Error fetching API from ${source.name}:`, error.message);
        }
      }

      // Deduplicate articles
      const uniqueArticles = this.deduplicateArticles(aggregatedNews);
      
      // Sort by relevance and recency
      uniqueArticles.sort((a, b) => {
        // Primary sort: relevance score
        const relevanceDiff = b.relevanceScore - a.relevanceScore;
        if (Math.abs(relevanceDiff) > 0.1) return relevanceDiff;
        
        // Secondary sort: publication date
        return new Date(b.publishedAt) - new Date(a.publishedAt);
      });

      // Store articles
      const finalArticles = uniqueArticles.slice(0, limit);
      for (const article of finalArticles) {
        this.articles.set(article.id, article);
      }

      console.log(`📰 Aggregated ${finalArticles.length} unique articles`);
      
      this.emit('newsAggregated', {
        totalArticles: finalArticles.length,
        sources: Array.from(new Set(finalArticles.map(a => a.source))),
        symbols: symbols
      });

      return finalArticles;

    } catch (error) {
      console.error('Error aggregating news:', error);
      return [];
    }
  }

  async fetchRSSFeed(source, symbols, limit) {
    // Mock RSS feed fetch - in production, use an RSS parser library
    const articles = [];
    
    for (let i = 0; i < Math.min(limit, 10); i++) {
      const mockArticle = this.generateMockArticle(source, symbols);
      articles.push(mockArticle);
    }
    
    return articles;
  }

  async fetchAPINews(source, symbols, limit) {
    const articles = [];
    
    try {
      if (source.name === 'NewsAPI Crypto') {
        const response = await this.fetchNewsAPI(symbols, limit);
        articles.push(...response);
      } else if (source.name === 'Twitter Sentiment') {
        const tweets = await this.fetchTwitterSentiment(symbols, limit);
        articles.push(...tweets);
      } else if (source.name === 'Reddit Crypto') {
        const posts = await this.fetchRedditPosts(symbols, limit);
        articles.push(...posts);
      }
    } catch (error) {
      console.error(`API fetch error for ${source.name}:`, error);
    }
    
    return articles;
  }

  generateMockArticle(source, symbols) {
    const symbol = symbols[Math.floor(Math.random() * symbols.length)];
    const sentiment = (Math.random() - 0.5) * 2; // -1 to 1
    
    const bullishTitles = [
      `${symbol} Breaks Key Resistance Level in Strong Rally`,
      `Institutional Investors Show Growing Interest in ${symbol}`,
      `${symbol} Network Upgrade Promises Enhanced Scalability`,
      `Major Exchange Lists ${symbol} Trading Pairs`,
      `${symbol} Adoption Accelerates Among Fortune 500 Companies`
    ];
    
    const bearishTitles = [
      `${symbol} Faces Regulatory Pressure in Key Markets`,
      `Technical Analysis Suggests ${symbol} Correction Incoming`,
      `${symbol} Network Experiences Temporary Congestion Issues`,
      `Market Volatility Impacts ${symbol} Trading Volume`,
      `${symbol} Faces Competition from Emerging Alternatives`
    ];
    
    const neutralTitles = [
      `${symbol} Price Analysis: What to Expect Next Week`,
      `${symbol} Development Team Releases Quarterly Update`,
      `Market Expert Discusses ${symbol} Long-term Outlook`,
      `${symbol} Trading Volume Remains Steady Despite Market Conditions`,
      `New Research Report Analyzes ${symbol} Market Dynamics`
    ];
    
    let title, category;
    if (sentiment > 0.3) {
      title = bullishTitles[Math.floor(Math.random() * bullishTitles.length)];
      category = 'bullish';
    } else if (sentiment < -0.3) {
      title = bearishTitles[Math.floor(Math.random() * bearishTitles.length)];
      category = 'bearish';
    } else {
      title = neutralTitles[Math.floor(Math.random() * neutralTitles.length)];
      category = 'neutral';
    }

    return {
      id: `article_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      title: title,
      summary: `Analysis of ${symbol} market conditions and recent developments...`,
      url: `${source.url}/article/${Date.now()}`,
      source: source.name,
      author: 'Crypto Analyst',
      publishedAt: new Date(Date.now() - Math.random() * 24 * 60 * 60 * 1000).toISOString(),
      
      // Sentiment analysis
      sentiment: {
        score: sentiment,
        confidence: Math.random() * 0.5 + 0.5, // 0.5 to 1.0
        category: category
      },
      
      // Relevance scoring
      relevanceScore: Math.random() * 0.3 + 0.7, // 0.7 to 1.0
      
      // Content analysis
      symbols: [symbol],
      keywords: this.extractKeywords(title),
      
      // Metadata
      readTime: Math.floor(Math.random() * 5) + 2, // 2-7 minutes
      category: 'market_analysis',
      credibility: source.credibility
    };
  }

  /**
   * Perform Sentiment Analysis
   */
  async analyzeSentiment(text, symbols = []) {
    const analysis = {
      score: 0,
      confidence: 0,
      category: 'neutral',
      breakdown: {
        positive: 0,
        negative: 0,
        neutral: 0
      },
      keywords: [],
      entities: symbols
    };

    try {
      // Simple rule-based sentiment analysis
      // In production, you'd use a proper NLP library or API
      
      const words = text.toLowerCase().split(/\s+/);
      let positiveScore = 0;
      let negativeScore = 0;
      let totalWords = words.length;

      // Define sentiment dictionaries
      const positiveWords = new Set([
        'good', 'great', 'excellent', 'amazing', 'awesome', 'fantastic', 'wonderful',
        'positive', 'bullish', 'up', 'rise', 'gain', 'profit', 'success', 'strong',
        'buy', 'accumulate', 'hodl', 'moon', 'pump', 'rally', 'surge', 'breakout'
      ]);

      const negativeWords = new Set([
        'bad', 'terrible', 'awful', 'horrible', 'negative', 'bearish', 'down',
        'fall', 'drop', 'loss', 'crash', 'dump', 'panic', 'fear', 'weak',
        'sell', 'correction', 'decline', 'plunge', 'collapse', 'bubble'
      ]);

      // Score words
      for (const word of words) {
        if (positiveWords.has(word)) {
          positiveScore += 1;
        } else if (negativeWords.has(word)) {
          negativeScore += 1;
        }
      }

      // Calculate final score
      const totalSentimentWords = positiveScore + negativeScore;
      if (totalSentimentWords > 0) {
        analysis.score = (positiveScore - negativeScore) / totalSentimentWords;
        analysis.confidence = Math.min(totalSentimentWords / totalWords * 10, 1.0);
      }

      // Determine category
      if (analysis.score > 0.2) {
        analysis.category = 'positive';
      } else if (analysis.score < -0.2) {
        analysis.category = 'negative';
      } else {
        analysis.category = 'neutral';
      }

      // Breakdown percentages
      if (totalSentimentWords > 0) {
        analysis.breakdown.positive = positiveScore / totalSentimentWords;
        analysis.breakdown.negative = negativeScore / totalSentimentWords;
        analysis.breakdown.neutral = 1 - analysis.breakdown.positive - analysis.breakdown.negative;
      } else {
        analysis.breakdown.neutral = 1;
      }

      // Extract relevant keywords
      analysis.keywords = this.extractKeywords(text);

    } catch (error) {
      console.error('Sentiment analysis error:', error);
    }

    return analysis;
  }

  extractKeywords(text) {
    const words = text.toLowerCase()
      .replace(/[^\w\s]/g, ' ')
      .split(/\s+/)
      .filter(word => word.length > 3);

    const relevantKeywords = words.filter(word => this.keywords.has(word));
    
    // Count frequency and return top keywords
    const frequency = {};
    for (const word of relevantKeywords) {
      frequency[word] = (frequency[word] || 0) + 1;
    }

    return Object.entries(frequency)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([word]) => word);
  }

  /**
   * Update Symbol Sentiment
   */
  async updateSymbolSentiment(symbol, articles) {
    const symbolData = this.sentimentData.get(symbol);
    if (!symbolData) return;

    const relevantArticles = articles.filter(article => 
      article.symbols && article.symbols.includes(symbol)
    );

    if (relevantArticles.length === 0) return;

    // Calculate weighted sentiment score
    let totalScore = 0;
    let totalWeight = 0;
    let bullishMentions = 0;
    let bearishMentions = 0;

    for (const article of relevantArticles) {
      const weight = article.credibility * article.relevanceScore;
      totalScore += article.sentiment.score * weight;
      totalWeight += weight;

      if (article.sentiment.score > 0.2) bullishMentions++;
      if (article.sentiment.score < -0.2) bearishMentions++;
    }

    const averageSentiment = totalWeight > 0 ? totalScore / totalWeight : 0;
    const confidence = Math.min(relevantArticles.length / 10, 1.0);

    // Update sentiment data
    symbolData.sentiment = {
      score: averageSentiment,
      confidence: confidence,
      trend: this.calculateSentimentTrend(symbolData.history, averageSentiment),
      lastUpdate: new Date().toISOString()
    };

    symbolData.metrics = {
      bullishMentions: bullishMentions,
      bearishMentions: bearishMentions,
      totalMentions: relevantArticles.length,
      influencerSentiment: this.calculateInfluencerSentiment(relevantArticles),
      socialVolume: this.calculateSocialVolume(relevantArticles),
      fearGreedIndex: this.calculateFearGreedIndex(averageSentiment)
    };

    // Add to history
    symbolData.history.push({
      timestamp: new Date().toISOString(),
      score: averageSentiment,
      confidence: confidence,
      mentions: relevantArticles.length
    });

    // Keep only last 100 history points
    if (symbolData.history.length > 100) {
      symbolData.history = symbolData.history.slice(-100);
    }

    console.log(`📊 Updated ${symbol} sentiment: ${averageSentiment.toFixed(3)} (${relevantArticles.length} articles)`);
  }

  calculateSentimentTrend(history, currentScore) {
    if (history.length < 2) return 'neutral';

    const recentScores = history.slice(-5).map(h => h.score);
    const average = recentScores.reduce((sum, score) => sum + score, 0) / recentScores.length;

    if (currentScore > average + 0.1) return 'improving';
    if (currentScore < average - 0.1) return 'declining';
    return 'stable';
  }

  calculateInfluencerSentiment(articles) {
    // Mock calculation - in production, weight by author influence
    const influencerArticles = articles.filter(a => a.credibility > 0.8);
    if (influencerArticles.length === 0) return 0;

    const totalScore = influencerArticles.reduce((sum, a) => sum + a.sentiment.score, 0);
    return totalScore / influencerArticles.length;
  }

  calculateSocialVolume(articles) {
    // Mock social volume calculation
    const socialArticles = articles.filter(a => a.category === 'social');
    return socialArticles.length * 100; // Mock volume metric
  }

  calculateFearGreedIndex(sentimentScore) {
    // Convert sentiment score (-1 to 1) to Fear & Greed Index (0 to 100)
    // 0-24: Extreme Fear, 25-49: Fear, 50-74: Greed, 75-100: Extreme Greed
    return Math.round((sentimentScore + 1) * 50);
  }

  /**
   * Generate Trading Signals from Sentiment
   */
  generateSentimentSignals(symbols) {
    const signals = [];

    for (const symbol of symbols) {
      const sentimentData = this.sentimentData.get(symbol);
      if (!sentimentData) continue;

      const sentiment = sentimentData.sentiment;
      const metrics = sentimentData.metrics;

      // Strong bullish sentiment signal
      if (sentiment.score > 0.5 && sentiment.confidence > 0.7 && metrics.bullishMentions > 5) {
        signals.push({
          symbol: symbol,
          type: 'BUY',
          strength: sentiment.score * sentiment.confidence,
          reason: 'Strong positive sentiment detected',
          source: 'sentiment_analysis',
          confidence: sentiment.confidence,
          timestamp: new Date().toISOString()
        });
      }

      // Strong bearish sentiment signal
      if (sentiment.score < -0.5 && sentiment.confidence > 0.7 && metrics.bearishMentions > 5) {
        signals.push({
          symbol: symbol,
          type: 'SELL',
          strength: Math.abs(sentiment.score) * sentiment.confidence,
          reason: 'Strong negative sentiment detected',
          source: 'sentiment_analysis',
          confidence: sentiment.confidence,
          timestamp: new Date().toISOString()
        });
      }

      // Sentiment divergence signal (contrarian)
      if (metrics.fearGreedIndex < 20 && sentiment.trend === 'improving') {
        signals.push({
          symbol: symbol,
          type: 'BUY',
          strength: 0.6,
          reason: 'Extreme fear with improving sentiment (contrarian)',
          source: 'sentiment_analysis',
          confidence: 0.6,
          timestamp: new Date().toISOString()
        });
      }
    }

    return signals;
  }

  /**
   * Helper Methods
   */
  deduplicateArticles(articles) {
    const seen = new Set();
    const unique = [];

    for (const article of articles) {
      // Use title similarity for deduplication
      const titleWords = article.title.toLowerCase().split(/\s+/).slice(0, 5).join(' ');
      
      if (!seen.has(titleWords)) {
        seen.add(titleWords);
        unique.push(article);
      }
    }

    return unique;
  }

  startNewsAggregation() {
    // Aggregate news every 30 minutes
    const aggregateNews = async () => {
      try {
        const symbols = ['BTC', 'ETH', 'BNB', 'ADA', 'SOL'];
        const articles = await this.aggregateNews(symbols, 100);
        
        // Update sentiment for each symbol
        for (const symbol of symbols) {
          await this.updateSymbolSentiment(symbol, articles);
        }
        
        // Generate trading signals
        const signals = this.generateSentimentSignals(symbols);
        if (signals.length > 0) {
          this.emit('sentimentSignals', signals);
        }
        
      } catch (error) {
        console.error('Error in news aggregation cycle:', error);
      }
    };

    // Initial aggregation
    aggregateNews();

    // Set up interval
    setInterval(aggregateNews, 30 * 60 * 1000); // 30 minutes
  }

  /**
   * Public API Methods
   */
  getNewsSummary(symbols = ['BTC', 'ETH'], limit = 10) {
    const allArticles = Array.from(this.articles.values());
    
    const relevantArticles = allArticles
      .filter(article => 
        !symbols.length || symbols.some(symbol => article.symbols.includes(symbol))
      )
      .sort((a, b) => new Date(b.publishedAt) - new Date(a.publishedAt))
      .slice(0, limit);

    return {
      articles: relevantArticles,
      summary: {
        totalArticles: relevantArticles.length,
        avgSentiment: relevantArticles.length > 0 
          ? relevantArticles.reduce((sum, a) => sum + a.sentiment.score, 0) / relevantArticles.length 
          : 0,
        sources: Array.from(new Set(relevantArticles.map(a => a.source))),
        lastUpdate: new Date().toISOString()
      }
    };
  }

  getSentimentAnalysis(symbol) {
    const data = this.sentimentData.get(symbol);
    if (!data) return null;

    return {
      symbol: symbol,
      current: data.sentiment,
      metrics: data.metrics,
      trend: data.sentiment.trend,
      history: data.history.slice(-24), // Last 24 data points
      signals: this.generateSentimentSignals([symbol])
    };
  }

  getMarketSentimentOverview() {
    const symbols = Array.from(this.sentimentData.keys());
    const overview = {};

    for (const symbol of symbols) {
      const data = this.sentimentData.get(symbol);
      overview[symbol] = {
        score: data.sentiment.score,
        trend: data.sentiment.trend,
        fearGreedIndex: data.metrics.fearGreedIndex,
        mentions: data.metrics.totalMentions
      };
    }

    // Calculate overall market sentiment
    const scores = symbols.map(s => this.sentimentData.get(s).sentiment.score);
    const overallSentiment = scores.length > 0 
      ? scores.reduce((sum, score) => sum + score, 0) / scores.length 
      : 0;

    return {
      overall: {
        sentiment: overallSentiment,
        fearGreedIndex: this.calculateFearGreedIndex(overallSentiment),
        trend: overallSentiment > 0.1 ? 'bullish' : overallSentiment < -0.1 ? 'bearish' : 'neutral'
      },
      bySymbol: overview,
      lastUpdate: new Date().toISOString()
    };
  }

  getStatus() {
    return {
      isInitialized: this.isInitialized,
      newsSources: this.newsSources.size,
      enabledSources: Array.from(this.newsSources.values()).filter(s => s.enabled).length,
      totalArticles: this.articles.size,
      trackedSymbols: this.sentimentData.size,
      lastAggregation: Array.from(this.newsSources.values())[0]?.lastFetch || null
    };
  }
}

module.exports = NewsSentimentEngine;