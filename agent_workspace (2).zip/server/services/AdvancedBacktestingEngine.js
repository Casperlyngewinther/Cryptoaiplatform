const EventEmitter = require('events');

/**
 * Advanced Backtesting Engine
 * High-performance backtesting with realistic market simulation
 */
class AdvancedBacktestingEngine extends EventEmitter {
  constructor() {
    super();
    this.strategies = new Map();
    this.backtestResults = new Map();
    this.marketData = new Map();
    this.isInitialized = false;
  }

  async initialize() {
    console.log('🔄 Initializing Advanced Backtesting Engine...');
    
    // Load historical market data
    await this.loadHistoricalData();
    
    this.isInitialized = true;
    console.log('✅ Advanced Backtesting Engine initialized');
  }

  async loadHistoricalData() {
    // In a real implementation, this would load from databases or APIs
    // For now, we'll simulate having the data
    const symbols = ['BTC/USDT', 'ETH/USDT', 'BNB/USDT', 'ADA/USDT'];
    
    for (const symbol of symbols) {
      this.marketData.set(symbol, {
        symbol: symbol,
        timeframes: ['1m', '5m', '15m', '1h', '4h', '1d'],
        dataLoaded: true,
        lastUpdate: new Date().toISOString()
      });
    }

    console.log(`📊 Historical data loaded for ${symbols.length} symbols`);
  }

  /**
   * Run Comprehensive Backtest
   */
  async runBacktest(config) {
    const backtestId = `backtest_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    console.log(`🧪 Starting backtest: ${config.name || backtestId}`);
    
    try {
      // Validate configuration
      this.validateBacktestConfig(config);
      
      // Initialize backtest state
      const state = this.initializeBacktestState(config);
      
      // Run the backtest simulation
      const results = await this.executeBacktest(backtestId, config, state);
      
      // Calculate comprehensive metrics
      const metrics = this.calculateBacktestMetrics(results, config);
      
      // Generate detailed report
      const report = this.generateBacktestReport(backtestId, config, results, metrics);
      
      // Store results
      this.backtestResults.set(backtestId, report);
      
      console.log(`✅ Backtest completed: ${config.name || backtestId}`);
      
      this.emit('backtestCompleted', report);
      
      return report;
      
    } catch (error) {
      console.error(`❌ Backtest failed: ${error.message}`);
      
      const errorReport = {
        id: backtestId,
        status: 'FAILED',
        error: error.message,
        timestamp: new Date().toISOString()
      };
      
      this.backtestResults.set(backtestId, errorReport);
      this.emit('backtestFailed', errorReport);
      
      throw error;
    }
  }

  validateBacktestConfig(config) {
    const required = ['strategy', 'symbol', 'startDate', 'endDate', 'initialCapital'];
    
    for (const field of required) {
      if (!config[field]) {
        throw new Error(`Missing required field: ${field}`);
      }
    }

    if (new Date(config.startDate) >= new Date(config.endDate)) {
      throw new Error('Start date must be before end date');
    }

    if (config.initialCapital <= 0) {
      throw new Error('Initial capital must be positive');
    }
  }

  initializeBacktestState(config) {
    return {
      // Portfolio state
      portfolio: {
        cash: config.initialCapital,
        positions: new Map(),
        totalValue: config.initialCapital,
        totalReturn: 0,
        unrealizedPnL: 0,
        realizedPnL: 0
      },
      
      // Trading state
      trading: {
        totalTrades: 0,
        winningTrades: 0,
        losingTrades: 0,
        totalFees: 0,
        totalSlippage: 0,
        openOrders: new Map(),
        tradeHistory: []
      },
      
      // Risk management
      risk: {
        maxDrawdown: 0,
        currentDrawdown: 0,
        peakValue: config.initialCapital,
        dailyReturns: [],
        monthlyReturns: []
      },
      
      // Strategy state
      strategy: {
        indicators: new Map(),
        signals: [],
        positions: new Map(),
        lastUpdate: null
      },
      
      // Market state
      market: {
        currentBar: 0,
        currentTime: null,
        currentPrice: null,
        volume: 0,
        priceHistory: []
      }
    };
  }

  async executeBacktest(backtestId, config, state) {
    const startTime = Date.now();
    
    // Get historical data for the specified period
    const historicalData = await this.getHistoricalData(
      config.symbol,
      config.timeframe || '1h',
      config.startDate,
      config.endDate
    );

    const totalBars = historicalData.length;
    let processedBars = 0;

    // Process each data point
    for (let i = 0; i < historicalData.length; i++) {
      const bar = historicalData[i];
      
      // Update market state
      this.updateMarketState(state, bar, i);
      
      // Update technical indicators
      await this.updateIndicators(state, bar, config.strategy);
      
      // Generate trading signals
      const signals = await this.generateSignals(state, config.strategy);
      
      // Execute trades based on signals
      await this.executeTrades(state, signals, config);
      
      // Update portfolio valuation
      this.updatePortfolioValue(state, bar);
      
      // Update risk metrics
      this.updateRiskMetrics(state);
      
      // Progress reporting
      processedBars++;
      if (processedBars % Math.floor(totalBars / 10) === 0) {
        const progress = Math.floor((processedBars / totalBars) * 100);
        console.log(`📈 Backtest progress: ${progress}%`);
        
        this.emit('backtestProgress', {
          backtestId: backtestId,
          progress: progress,
          processedBars: processedBars,
          totalBars: totalBars
        });
      }
    }

    const executionTime = Date.now() - startTime;
    
    return {
      executionTime: executionTime,
      totalBars: totalBars,
      finalState: state,
      historicalData: historicalData
    };
  }

  updateMarketState(state, bar, index) {
    state.market.currentBar = index;
    state.market.currentTime = bar.timestamp;
    state.market.currentPrice = bar.close;
    state.market.volume = bar.volume;
    
    state.market.priceHistory.push({
      timestamp: bar.timestamp,
      price: bar.close,
      volume: bar.volume
    });
  }

  async updateIndicators(state, bar, strategy) {
    // Update technical indicators based on strategy requirements
    const indicators = strategy.indicators || [];
    
    for (const indicatorConfig of indicators) {
      const indicator = await this.calculateIndicator(
        indicatorConfig.type,
        indicatorConfig.parameters,
        state.market.priceHistory
      );
      
      state.strategy.indicators.set(indicatorConfig.name, indicator);
    }
  }

  async calculateIndicator(type, parameters, priceHistory) {
    // Simplified technical indicator calculations
    // In production, you'd use a proper technical analysis library
    
    switch (type) {
      case 'SMA':
        return this.calculateSMA(priceHistory, parameters.period);
      
      case 'EMA':
        return this.calculateEMA(priceHistory, parameters.period);
      
      case 'RSI':
        return this.calculateRSI(priceHistory, parameters.period);
      
      case 'MACD':
        return this.calculateMACD(priceHistory, parameters.fast, parameters.slow, parameters.signal);
      
      case 'BOLLINGER_BANDS':
        return this.calculateBollingerBands(priceHistory, parameters.period, parameters.stdDev);
      
      default:
        return null;
    }
  }

  calculateSMA(priceHistory, period) {
    if (priceHistory.length < period) return null;
    
    const prices = priceHistory.slice(-period).map(p => p.price);
    const sum = prices.reduce((acc, price) => acc + price, 0);
    
    return sum / period;
  }

  calculateEMA(priceHistory, period) {
    if (priceHistory.length < period) return null;
    
    const multiplier = 2 / (period + 1);
    let ema = priceHistory[0].price;
    
    for (let i = 1; i < priceHistory.length; i++) {
      ema = (priceHistory[i].price - ema) * multiplier + ema;
    }
    
    return ema;
  }

  calculateRSI(priceHistory, period = 14) {
    if (priceHistory.length < period + 1) return null;
    
    let gains = 0;
    let losses = 0;
    
    for (let i = priceHistory.length - period; i < priceHistory.length; i++) {
      const change = priceHistory[i].price - priceHistory[i - 1].price;
      if (change > 0) {
        gains += change;
      } else {
        losses -= change;
      }
    }
    
    const avgGain = gains / period;
    const avgLoss = losses / period;
    
    if (avgLoss === 0) return 100;
    
    const rs = avgGain / avgLoss;
    return 100 - (100 / (1 + rs));
  }

  calculateMACD(priceHistory, fastPeriod = 12, slowPeriod = 26, signalPeriod = 9) {
    const fastEMA = this.calculateEMA(priceHistory, fastPeriod);
    const slowEMA = this.calculateEMA(priceHistory, slowPeriod);
    
    if (!fastEMA || !slowEMA) return null;
    
    const macdLine = fastEMA - slowEMA;
    
    // For simplicity, returning just the MACD line
    // In production, you'd also calculate the signal line and histogram
    return {
      macd: macdLine,
      signal: null,
      histogram: null
    };
  }

  calculateBollingerBands(priceHistory, period = 20, stdDev = 2) {
    const sma = this.calculateSMA(priceHistory, period);
    if (!sma) return null;
    
    const prices = priceHistory.slice(-period).map(p => p.price);
    const variance = prices.reduce((acc, price) => acc + Math.pow(price - sma, 2), 0) / period;
    const standardDeviation = Math.sqrt(variance);
    
    return {
      middle: sma,
      upper: sma + (standardDeviation * stdDev),
      lower: sma - (standardDeviation * stdDev)
    };
  }

  async generateSignals(state, strategy) {
    const signals = [];
    
    // Execute strategy rules to generate signals
    const rules = strategy.rules || [];
    
    for (const rule of rules) {
      const signal = await this.evaluateRule(rule, state);
      if (signal) {
        signals.push(signal);
      }
    }
    
    return signals;
  }

  async evaluateRule(rule, state) {
    // Simplified rule evaluation
    // In production, you'd have a more sophisticated rule engine
    
    try {
      // Example rule evaluation
      if (rule.type === 'CROSS_ABOVE') {
        const indicator1 = state.strategy.indicators.get(rule.indicator1);
        const indicator2 = state.strategy.indicators.get(rule.indicator2);
        
        if (indicator1 && indicator2 && indicator1 > indicator2) {
          return {
            type: 'BUY',
            strength: rule.strength || 1.0,
            reason: `${rule.indicator1} crossed above ${rule.indicator2}`,
            timestamp: state.market.currentTime
          };
        }
      }
      
      if (rule.type === 'CROSS_BELOW') {
        const indicator1 = state.strategy.indicators.get(rule.indicator1);
        const indicator2 = state.strategy.indicators.get(rule.indicator2);
        
        if (indicator1 && indicator2 && indicator1 < indicator2) {
          return {
            type: 'SELL',
            strength: rule.strength || 1.0,
            reason: `${rule.indicator1} crossed below ${rule.indicator2}`,
            timestamp: state.market.currentTime
          };
        }
      }
      
    } catch (error) {
      console.error('Error evaluating rule:', error);
    }
    
    return null;
  }

  async executeTrades(state, signals, config) {
    for (const signal of signals) {
      await this.executeSignal(state, signal, config);
    }
  }

  async executeSignal(state, signal, config) {
    const portfolio = state.portfolio;
    const trading = state.trading;
    const currentPrice = state.market.currentPrice;
    
    // Position sizing
    const positionSize = this.calculatePositionSize(state, signal, config);
    if (positionSize <= 0) return;
    
    // Calculate fees and slippage
    const fees = this.calculateFees(positionSize, currentPrice, config);
    const slippage = this.calculateSlippage(positionSize, currentPrice, config);
    const effectivePrice = currentPrice + (signal.type === 'BUY' ? slippage : -slippage);
    
    if (signal.type === 'BUY') {
      const totalCost = (positionSize * effectivePrice) + fees;
      
      if (portfolio.cash >= totalCost) {
        // Execute buy order
        portfolio.cash -= totalCost;
        
        const currentPosition = portfolio.positions.get(config.symbol) || 0;
        portfolio.positions.set(config.symbol, currentPosition + positionSize);
        
        // Record trade
        trading.tradeHistory.push({
          id: `trade_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          timestamp: state.market.currentTime,
          type: 'BUY',
          symbol: config.symbol,
          quantity: positionSize,
          price: effectivePrice,
          fees: fees,
          slippage: slippage,
          signal: signal
        });
        
        trading.totalTrades++;
        trading.totalFees += fees;
        trading.totalSlippage += slippage;
      }
      
    } else if (signal.type === 'SELL') {
      const currentPosition = portfolio.positions.get(config.symbol) || 0;
      const sellQuantity = Math.min(positionSize, currentPosition);
      
      if (sellQuantity > 0) {
        // Execute sell order
        const totalReceived = (sellQuantity * effectivePrice) - fees;
        portfolio.cash += totalReceived;
        
        portfolio.positions.set(config.symbol, currentPosition - sellQuantity);
        
        // Record trade
        trading.tradeHistory.push({
          id: `trade_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          timestamp: state.market.currentTime,
          type: 'SELL',
          symbol: config.symbol,
          quantity: sellQuantity,
          price: effectivePrice,
          fees: fees,
          slippage: slippage,
          signal: signal
        });
        
        trading.totalTrades++;
        trading.totalFees += fees;
        trading.totalSlippage += slippage;
      }
    }
  }

  calculatePositionSize(state, signal, config) {
    const positionSizing = config.positionSizing || { type: 'FIXED_PERCENT', value: 0.1 };
    
    switch (positionSizing.type) {
      case 'FIXED_AMOUNT':
        return positionSizing.value / state.market.currentPrice;
      
      case 'FIXED_PERCENT':
        return (state.portfolio.totalValue * positionSizing.value) / state.market.currentPrice;
      
      case 'KELLY_CRITERION':
        // Simplified Kelly Criterion implementation
        const winRate = config.winRate || 0.6;
        const avgWin = config.avgWin || 0.02;
        const avgLoss = config.avgLoss || 0.01;
        
        const kelly = (winRate * avgWin - (1 - winRate) * avgLoss) / avgWin;
        const kellyPercent = Math.max(0, Math.min(kelly * 0.25, 0.1)); // Conservative Kelly
        
        return (state.portfolio.totalValue * kellyPercent) / state.market.currentPrice;
      
      default:
        return 0;
    }
  }

  calculateFees(quantity, price, config) {
    const feeConfig = config.fees || { type: 'PERCENTAGE', value: 0.001 };
    
    switch (feeConfig.type) {
      case 'PERCENTAGE':
        return quantity * price * feeConfig.value;
      
      case 'FIXED':
        return feeConfig.value;
      
      default:
        return 0;
    }
  }

  calculateSlippage(quantity, price, config) {
    const slippageConfig = config.slippage || { type: 'PERCENTAGE', value: 0.0001 };
    
    switch (slippageConfig.type) {
      case 'PERCENTAGE':
        return price * slippageConfig.value;
      
      case 'FIXED':
        return slippageConfig.value;
      
      default:
        return 0;
    }
  }

  updatePortfolioValue(state, bar) {
    const portfolio = state.portfolio;
    const currentPrice = bar.close;
    
    // Calculate unrealized P&L
    let totalPositionValue = 0;
    for (const [symbol, quantity] of portfolio.positions) {
      totalPositionValue += quantity * currentPrice;
    }
    
    portfolio.totalValue = portfolio.cash + totalPositionValue;
    portfolio.unrealizedPnL = totalPositionValue - (portfolio.totalValue - portfolio.cash);
    portfolio.totalReturn = ((portfolio.totalValue / state.portfolio.cash) - 1) * 100;
  }

  updateRiskMetrics(state) {
    const portfolio = state.portfolio;
    const risk = state.risk;
    
    // Update peak value and drawdown
    if (portfolio.totalValue > risk.peakValue) {
      risk.peakValue = portfolio.totalValue;
      risk.currentDrawdown = 0;
    } else {
      risk.currentDrawdown = ((risk.peakValue - portfolio.totalValue) / risk.peakValue) * 100;
      risk.maxDrawdown = Math.max(risk.maxDrawdown, risk.currentDrawdown);
    }
    
    // Calculate daily returns (simplified)
    if (risk.dailyReturns.length > 0) {
      const previousValue = risk.dailyReturns[risk.dailyReturns.length - 1].value;
      const dailyReturn = ((portfolio.totalValue - previousValue) / previousValue) * 100;
      
      risk.dailyReturns.push({
        date: state.market.currentTime,
        value: portfolio.totalValue,
        return: dailyReturn
      });
    } else {
      risk.dailyReturns.push({
        date: state.market.currentTime,
        value: portfolio.totalValue,
        return: 0
      });
    }
  }

  calculateBacktestMetrics(results, config) {
    const state = results.finalState;
    const portfolio = state.portfolio;
    const trading = state.trading;
    const risk = state.risk;
    
    // Basic performance metrics
    const totalReturn = portfolio.totalReturn;
    const winRate = trading.winningTrades / trading.totalTrades || 0;
    const profitFactor = this.calculateProfitFactor(trading.tradeHistory);
    const sharpeRatio = this.calculateSharpeRatio(risk.dailyReturns);
    const calmarRatio = totalReturn / (risk.maxDrawdown || 1);
    
    // Advanced metrics
    const volatility = this.calculateVolatility(risk.dailyReturns);
    const sortino = this.calculateSortinoRatio(risk.dailyReturns);
    const var95 = this.calculateVaR(risk.dailyReturns, 0.95);
    const cvar95 = this.calculateCVaR(risk.dailyReturns, 0.95);
    
    // Trade analysis
    const avgTradeDuration = this.calculateAverageTradeDuration(trading.tradeHistory);
    const avgWin = this.calculateAverageWin(trading.tradeHistory);
    const avgLoss = this.calculateAverageLoss(trading.tradeHistory);
    const largestWin = this.calculateLargestWin(trading.tradeHistory);
    const largestLoss = this.calculateLargestLoss(trading.tradeHistory);
    
    return {
      performance: {
        totalReturn: totalReturn,
        annualizedReturn: this.annualizeReturn(totalReturn, config.startDate, config.endDate),
        winRate: winRate,
        profitFactor: profitFactor,
        sharpeRatio: sharpeRatio,
        calmarRatio: calmarRatio,
        sortinoRatio: sortino
      },
      
      risk: {
        maxDrawdown: risk.maxDrawdown,
        volatility: volatility,
        valueAtRisk95: var95,
        conditionalVaR95: cvar95,
        downside_deviation: this.calculateDownsideDeviation(risk.dailyReturns)
      },
      
      trading: {
        totalTrades: trading.totalTrades,
        winningTrades: trading.winningTrades,
        losingTrades: trading.losingTrades,
        avgTradeDuration: avgTradeDuration,
        avgWin: avgWin,
        avgLoss: avgLoss,
        largestWin: largestWin,
        largestLoss: largestLoss,
        totalFees: trading.totalFees,
        totalSlippage: trading.totalSlippage
      },
      
      portfolio: {
        initialCapital: config.initialCapital,
        finalValue: portfolio.totalValue,
        maxValue: risk.peakValue,
        minValue: Math.min(...risk.dailyReturns.map(d => d.value))
      }
    };
  }

  calculateProfitFactor(trades) {
    const winningTrades = trades.filter(t => t.pnl > 0);
    const losingTrades = trades.filter(t => t.pnl < 0);
    
    const totalProfit = winningTrades.reduce((sum, t) => sum + t.pnl, 0);
    const totalLoss = Math.abs(losingTrades.reduce((sum, t) => sum + t.pnl, 0));
    
    return totalLoss > 0 ? totalProfit / totalLoss : 0;
  }

  calculateSharpeRatio(dailyReturns, riskFreeRate = 0.02) {
    if (dailyReturns.length < 2) return 0;
    
    const returns = dailyReturns.slice(1).map(d => d.return);
    const avgReturn = returns.reduce((sum, r) => sum + r, 0) / returns.length;
    const volatility = this.calculateVolatility(dailyReturns);
    
    if (volatility === 0) return 0;
    
    const annualizedReturn = avgReturn * 252; // 252 trading days
    const annualizedVolatility = volatility * Math.sqrt(252);
    
    return (annualizedReturn - riskFreeRate) / annualizedVolatility;
  }

  calculateVolatility(dailyReturns) {
    if (dailyReturns.length < 2) return 0;
    
    const returns = dailyReturns.slice(1).map(d => d.return);
    const avgReturn = returns.reduce((sum, r) => sum + r, 0) / returns.length;
    
    const variance = returns.reduce((sum, r) => sum + Math.pow(r - avgReturn, 2), 0) / returns.length;
    return Math.sqrt(variance);
  }

  generateBacktestReport(backtestId, config, results, metrics) {
    return {
      id: backtestId,
      status: 'COMPLETED',
      
      config: {
        name: config.name,
        strategy: config.strategy.name,
        symbol: config.symbol,
        timeframe: config.timeframe,
        startDate: config.startDate,
        endDate: config.endDate,
        initialCapital: config.initialCapital
      },
      
      execution: {
        executionTime: results.executionTime,
        totalBars: results.totalBars,
        dataPoints: results.historicalData.length
      },
      
      metrics: metrics,
      
      portfolio: {
        equityCurve: results.finalState.risk.dailyReturns,
        positions: Array.from(results.finalState.portfolio.positions.entries()),
        trades: results.finalState.trading.tradeHistory
      },
      
      timestamp: new Date().toISOString(),
      
      // Summary
      summary: {
        profitable: metrics.performance.totalReturn > 0,
        grade: this.calculateBacktestGrade(metrics),
        recommendations: this.generateRecommendations(metrics)
      }
    };
  }

  calculateBacktestGrade(metrics) {
    let score = 0;
    
    // Performance scoring
    if (metrics.performance.totalReturn > 20) score += 25;
    else if (metrics.performance.totalReturn > 10) score += 20;
    else if (metrics.performance.totalReturn > 5) score += 15;
    else if (metrics.performance.totalReturn > 0) score += 10;
    
    // Risk scoring
    if (metrics.risk.maxDrawdown < 5) score += 25;
    else if (metrics.risk.maxDrawdown < 10) score += 20;
    else if (metrics.risk.maxDrawdown < 15) score += 15;
    else if (metrics.risk.maxDrawdown < 20) score += 10;
    
    // Sharpe ratio scoring
    if (metrics.performance.sharpeRatio > 2) score += 25;
    else if (metrics.performance.sharpeRatio > 1.5) score += 20;
    else if (metrics.performance.sharpeRatio > 1) score += 15;
    else if (metrics.performance.sharpeRatio > 0.5) score += 10;
    
    // Win rate scoring
    if (metrics.performance.winRate > 0.7) score += 25;
    else if (metrics.performance.winRate > 0.6) score += 20;
    else if (metrics.performance.winRate > 0.5) score += 15;
    else if (metrics.performance.winRate > 0.4) score += 10;
    
    // Grade assignment
    if (score >= 90) return 'A+';
    if (score >= 80) return 'A';
    if (score >= 70) return 'B+';
    if (score >= 60) return 'B';
    if (score >= 50) return 'C';
    return 'D';
  }

  generateRecommendations(metrics) {
    const recommendations = [];
    
    if (metrics.performance.totalReturn < 0) {
      recommendations.push('Strategy is unprofitable. Consider revising entry/exit rules.');
    }
    
    if (metrics.risk.maxDrawdown > 20) {
      recommendations.push('High drawdown detected. Implement better risk management.');
    }
    
    if (metrics.performance.winRate < 0.4) {
      recommendations.push('Low win rate. Review signal quality and entry conditions.');
    }
    
    if (metrics.performance.sharpeRatio < 1) {
      recommendations.push('Poor risk-adjusted returns. Optimize position sizing.');
    }
    
    if (metrics.trading.totalTrades < 30) {
      recommendations.push('Limited trade sample. Consider longer backtest period.');
    }
    
    return recommendations;
  }

  async getHistoricalData(symbol, timeframe, startDate, endDate) {
    // Mock historical data generation
    // In production, this would fetch from real data sources
    
    const start = new Date(startDate);
    const end = new Date(endDate);
    const data = [];
    
    // Generate sample OHLCV data
    let currentTime = start;
    let currentPrice = 50000; // Starting price
    
    const timeframeMs = this.getTimeframeMs(timeframe);
    
    while (currentTime <= end) {
      // Generate realistic price movement
      const volatility = 0.02;
      const change = (Math.random() - 0.5) * volatility;
      
      const open = currentPrice;
      const close = currentPrice * (1 + change);
      const high = Math.max(open, close) * (1 + Math.random() * 0.01);
      const low = Math.min(open, close) * (1 - Math.random() * 0.01);
      const volume = Math.random() * 1000000;
      
      data.push({
        timestamp: currentTime.toISOString(),
        open: open,
        high: high,
        low: low,
        close: close,
        volume: volume
      });
      
      currentPrice = close;
      currentTime = new Date(currentTime.getTime() + timeframeMs);
    }
    
    return data;
  }

  getTimeframeMs(timeframe) {
    const timeframes = {
      '1m': 60 * 1000,
      '5m': 5 * 60 * 1000,
      '15m': 15 * 60 * 1000,
      '1h': 60 * 60 * 1000,
      '4h': 4 * 60 * 60 * 1000,
      '1d': 24 * 60 * 60 * 1000
    };
    
    return timeframes[timeframe] || timeframes['1h'];
  }

  getStatus() {
    return {
      isInitialized: this.isInitialized,
      supportedSymbols: this.marketData.size,
      completedBacktests: this.backtestResults.size,
      dataAvailable: Array.from(this.marketData.keys())
    };
  }
}

module.exports = AdvancedBacktestingEngine;