const express = require('express');
const path = require('path');

/**
 * Mobile API & Progressive Web App (PWA) Engine
 * Provides optimized mobile API endpoints and PWA functionality
 */
class MobilePWAEngine {
  constructor() {
    this.router = express.Router();
    this.pushSubscriptions = new Map();
    this.mobileConfig = {
      maxDataPoints: 100, // Limit data for mobile
      updateInterval: 30000, // 30 seconds
      compressionEnabled: true,
      offlineSupport: true
    };
    this.isInitialized = false;
  }

  async initialize() {
    console.log('🔄 Initializing Mobile & PWA Engine...');
    
    // Setup mobile-optimized API routes
    this.setupMobileRoutes();
    
    // Setup PWA routes
    this.setupPWARoutes();
    
    // Setup push notification system
    this.setupPushNotifications();
    
    this.isInitialized = true;
    console.log('✅ Mobile & PWA Engine initialized');
  }

  setupMobileRoutes() {
    // Mobile-optimized portfolio summary
    this.router.get('/mobile/portfolio/summary', async (req, res) => {
      try {
        const summary = await this.getMobilePortfolioSummary();
        res.json({
          success: true,
          data: summary,
          timestamp: new Date().toISOString(),
          cached: false
        });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    // Mobile-optimized market data
    this.router.get('/mobile/markets/summary', async (req, res) => {
      try {
        const limit = parseInt(req.query.limit) || 10;
        const markets = await this.getMobileMarketSummary(limit);
        
        res.json({
          success: true,
          data: markets,
          timestamp: new Date().toISOString(),
          cached: false
        });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    // Mobile-optimized charts
    this.router.get('/mobile/charts/:symbol', async (req, res) => {
      try {
        const { symbol } = req.params;
        const { timeframe = '1h', points = 50 } = req.query;
        
        const chartData = await this.getMobileChartData(symbol, timeframe, points);
        
        res.json({
          success: true,
          data: chartData,
          timestamp: new Date().toISOString()
        });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    // Mobile alerts
    this.router.get('/mobile/alerts', async (req, res) => {
      try {
        const userId = req.query.userId;
        const alerts = await this.getMobileAlerts(userId);
        
        res.json({
          success: true,
          data: alerts,
          timestamp: new Date().toISOString()
        });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    // Quick trade endpoint
    this.router.post('/mobile/trade/quick', async (req, res) => {
      try {
        const { symbol, action, amount, type = 'market' } = req.body;
        
        const result = await this.executeQuickTrade({
          symbol,
          action,
          amount,
          type
        });
        
        res.json({
          success: true,
          data: result,
          timestamp: new Date().toISOString()
        });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    // Mobile-optimized news
    this.router.get('/mobile/news', async (req, res) => {
      try {
        const limit = parseInt(req.query.limit) || 5;
        const category = req.query.category || 'all';
        
        const news = await this.getMobileNews(limit, category);
        
        res.json({
          success: true,
          data: news,
          timestamp: new Date().toISOString()
        });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    // Mobile performance metrics
    this.router.get('/mobile/performance', async (req, res) => {
      try {
        const userId = req.query.userId;
        const timeframe = req.query.timeframe || '7d';
        
        const performance = await this.getMobilePerformanceMetrics(userId, timeframe);
        
        res.json({
          success: true,
          data: performance,
          timestamp: new Date().toISOString()
        });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });
  }

  setupPWARoutes() {
    // Service Worker
    this.router.get('/pwa/sw.js', (req, res) => {
      res.setHeader('Content-Type', 'application/javascript');
      res.send(this.generateServiceWorker());
    });

    // Web App Manifest
    this.router.get('/pwa/manifest.json', (req, res) => {
      res.setHeader('Content-Type', 'application/json');
      res.json(this.generateWebAppManifest());
    });

    // Offline fallback page
    this.router.get('/pwa/offline.html', (req, res) => {
      res.setHeader('Content-Type', 'text/html');
      res.send(this.generateOfflinePage());
    });

    // PWA installation status
    this.router.get('/pwa/install-status', (req, res) => {
      res.json({
        installable: true,
        prompt: 'Add CryptoAI to your home screen for quick access!',
        features: [
          'Offline portfolio viewing',
          'Push notifications for alerts',
          'Quick trade actions',
          'Real-time price updates'
        ]
      });
    });
  }

  setupPushNotifications() {
    // Subscribe to push notifications
    this.router.post('/mobile/push/subscribe', async (req, res) => {
      try {
        const { userId, subscription } = req.body;
        
        this.pushSubscriptions.set(userId, {
          subscription: subscription,
          subscribed: new Date().toISOString(),
          active: true
        });
        
        console.log(`📱 Push subscription added for user: ${userId}`);
        
        res.json({
          success: true,
          message: 'Push notifications enabled'
        });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    // Unsubscribe from push notifications
    this.router.post('/mobile/push/unsubscribe', async (req, res) => {
      try {
        const { userId } = req.body;
        
        if (this.pushSubscriptions.has(userId)) {
          this.pushSubscriptions.delete(userId);
          console.log(`📱 Push subscription removed for user: ${userId}`);
        }
        
        res.json({
          success: true,
          message: 'Push notifications disabled'
        });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    // Send test notification
    this.router.post('/mobile/push/test', async (req, res) => {
      try {
        const { userId } = req.body;
        
        await this.sendPushNotification(userId, {
          title: 'CryptoAI Test Notification',
          body: 'Push notifications are working correctly!',
          icon: '/icons/icon-192x192.png',
          badge: '/icons/badge-72x72.png'
        });
        
        res.json({
          success: true,
          message: 'Test notification sent'
        });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });
  }

  async getMobilePortfolioSummary() {
    // Optimized portfolio data for mobile
    return {
      totalValue: 25750.50,
      totalPnL: 2750.50,
      totalPnLPercent: 11.98,
      dayChange: 450.25,
      dayChangePercent: 1.78,
      
      topPositions: [
        {
          symbol: 'BTC',
          value: 15000,
          percentage: 58.3,
          change: 2.5,
          color: '#f7931a'
        },
        {
          symbol: 'ETH',
          value: 6500,
          percentage: 25.2,
          change: -1.2,
          color: '#627eea'
        },
        {
          symbol: 'BNB',
          value: 2250,
          percentage: 8.7,
          change: 0.8,
          color: '#f3ba2f'
        }
      ],
      
      quickStats: {
        connectedExchanges: 4,
        totalTrades: 127,
        winRate: 68.5,
        bestPerformer: 'BTC (+2.5%)',
        worstPerformer: 'ETH (-1.2%)'
      }
    };
  }

  async getMobileMarketSummary(limit = 10) {
    // Mock data - replace with real market data
    const markets = [
      { symbol: 'BTC/USDT', price: 43250.50, change: 2.5, volume: '2.1B', color: '#f7931a' },
      { symbol: 'ETH/USDT', price: 2485.75, change: -1.2, volume: '1.8B', color: '#627eea' },
      { symbol: 'BNB/USDT', price: 315.20, change: 0.8, volume: '456M', color: '#f3ba2f' },
      { symbol: 'ADA/USDT', price: 0.4520, change: 3.2, volume: '287M', color: '#0033ad' },
      { symbol: 'SOL/USDT', price: 95.45, change: -0.5, volume: '523M', color: '#00d4aa' }
    ];
    
    return markets.slice(0, limit).map(market => ({
      ...market,
      trend: market.change > 0 ? 'up' : 'down',
      formattedPrice: this.formatPrice(market.price),
      formattedChange: this.formatPercentage(market.change)
    }));
  }

  async getMobileChartData(symbol, timeframe, points) {
    // Generate sample chart data optimized for mobile
    const data = [];
    const now = Date.now();
    const interval = this.getTimeframeMs(timeframe);
    
    let price = 43000; // Starting price
    
    for (let i = points; i >= 0; i--) {
      const timestamp = now - (i * interval);
      const change = (Math.random() - 0.5) * 0.02; // 2% max change
      price = price * (1 + change);
      
      data.push({
        timestamp: timestamp,
        price: price,
        volume: Math.random() * 1000000
      });
    }
    
    return {
      symbol: symbol,
      timeframe: timeframe,
      data: data,
      summary: {
        high: Math.max(...data.map(d => d.price)),
        low: Math.min(...data.map(d => d.price)),
        change: ((data[data.length - 1].price - data[0].price) / data[0].price) * 100
      }
    };
  }

  async getMobileAlerts(userId) {
    // Mock alert data
    return {
      active: [
        {
          id: 'alert_1',
          type: 'PRICE',
          message: 'BTC crossed $44,000',
          timestamp: new Date().toISOString(),
          severity: 'medium',
          action: 'View Chart'
        },
        {
          id: 'alert_2',
          type: 'PORTFOLIO',
          message: 'Portfolio up 2.5% today',
          timestamp: new Date(Date.now() - 3600000).toISOString(),
          severity: 'low',
          action: 'View Portfolio'
        }
      ],
      
      settings: {
        priceAlerts: true,
        portfolioAlerts: true,
        newsAlerts: false,
        pushEnabled: true
      }
    };
  }

  async executeQuickTrade(tradeData) {
    // Simulate quick trade execution
    const { symbol, action, amount, type } = tradeData;
    
    // Basic validation
    if (!symbol || !action || !amount) {
      throw new Error('Missing required trade parameters');
    }
    
    if (!['buy', 'sell'].includes(action.toLowerCase())) {
      throw new Error('Invalid trade action');
    }
    
    // Mock execution result
    return {
      orderId: `order_${Date.now()}`,
      status: 'FILLED',
      symbol: symbol,
      action: action.toUpperCase(),
      amount: amount,
      price: 43250.50, // Mock current price
      fee: amount * 0.001, // 0.1% fee
      timestamp: new Date().toISOString(),
      executionTime: 1.2 // seconds
    };
  }

  async getMobileNews(limit, category) {
    // Mock news data
    const news = [
      {
        id: 'news_1',
        title: 'Bitcoin Reaches New Monthly High',
        summary: 'BTC surges past $44,000 as institutional adoption continues...',
        category: 'market',
        timestamp: new Date().toISOString(),
        source: 'CryptoNews',
        impact: 'positive'
      },
      {
        id: 'news_2',
        title: 'Ethereum Network Upgrade Announced',
        summary: 'New upgrade promises improved scalability and lower fees...',
        category: 'technology',
        timestamp: new Date(Date.now() - 1800000).toISOString(),
        source: 'EthDaily',
        impact: 'positive'
      },
      {
        id: 'news_3',
        title: 'Regulatory Clarity Improves Market Sentiment',
        summary: 'New guidelines provide clearer framework for crypto operations...',
        category: 'regulation',
        timestamp: new Date(Date.now() - 3600000).toISOString(),
        source: 'RegulatoryWatch',
        impact: 'positive'
      }
    ];
    
    return news.slice(0, limit);
  }

  async getMobilePerformanceMetrics(userId, timeframe) {
    // Mock performance data
    return {
      timeframe: timeframe,
      metrics: {
        totalReturn: 11.98,
        winRate: 68.5,
        sharpeRatio: 1.45,
        maxDrawdown: 8.2,
        totalTrades: 127,
        profitableTrades: 87
      },
      
      chart: {
        labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        data: [23000, 23500, 24100, 23800, 24500, 25200, 25750]
      },
      
      breakdown: {
        trading: 8.5,
        defi: 2.1,
        staking: 1.38
      }
    };
  }

  generateServiceWorker() {
    return `
// CryptoAI Service Worker
const CACHE_NAME = 'cryptoai-v1';
const urlsToCache = [
  '/',
  '/pwa/offline.html',
  '/css/mobile.css',
  '/js/mobile.js',
  '/icons/icon-192x192.png',
  '/icons/icon-512x512.png'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(urlsToCache))
  );
});

self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        // Return cached version or fetch from network
        return response || fetch(event.request);
      })
      .catch(() => {
        // Show offline page for navigation requests
        if (event.request.mode === 'navigate') {
          return caches.match('/pwa/offline.html');
        }
      })
  );
});

// Push notification handling
self.addEventListener('push', event => {
  const options = {
    body: event.data ? event.data.text() : 'New notification',
    icon: '/icons/icon-192x192.png',
    badge: '/icons/badge-72x72.png',
    vibrate: [100, 50, 100],
    data: {
      dateOfArrival: Date.now(),
      primaryKey: 1
    },
    actions: [
      {
        action: 'explore',
        title: 'Open App',
        icon: '/icons/checkmark.png'
      },
      {
        action: 'close',
        title: 'Close',
        icon: '/icons/xmark.png'
      }
    ]
  };

  event.waitUntil(
    self.registration.showNotification('CryptoAI', options)
  );
});

self.addEventListener('notificationclick', event => {
  event.notification.close();

  if (event.action === 'explore') {
    // Open or focus the app
    event.waitUntil(
      clients.openWindow('/')
    );
  }
});
    `.trim();
  }

  generateWebAppManifest() {
    return {
      name: 'CryptoAI Trading Platform',
      short_name: 'CryptoAI',
      description: 'AI-powered cryptocurrency trading platform',
      start_url: '/',
      display: 'standalone',
      theme_color: '#1a1a1a',
      background_color: '#ffffff',
      orientation: 'portrait-primary',
      
      icons: [
        {
          src: '/icons/icon-72x72.png',
          sizes: '72x72',
          type: 'image/png'
        },
        {
          src: '/icons/icon-96x96.png',
          sizes: '96x96',
          type: 'image/png'
        },
        {
          src: '/icons/icon-128x128.png',
          sizes: '128x128',
          type: 'image/png'
        },
        {
          src: '/icons/icon-144x144.png',
          sizes: '144x144',
          type: 'image/png'
        },
        {
          src: '/icons/icon-152x152.png',
          sizes: '152x152',
          type: 'image/png'
        },
        {
          src: '/icons/icon-192x192.png',
          sizes: '192x192',
          type: 'image/png'
        },
        {
          src: '/icons/icon-384x384.png',
          sizes: '384x384',
          type: 'image/png'
        },
        {
          src: '/icons/icon-512x512.png',
          sizes: '512x512',
          type: 'image/png'
        }
      ],
      
      shortcuts: [
        {
          name: 'Portfolio',
          short_name: 'Portfolio',
          description: 'View your portfolio',
          url: '/portfolio',
          icons: [{ src: '/icons/portfolio-96x96.png', sizes: '96x96' }]
        },
        {
          name: 'Markets',
          short_name: 'Markets',
          description: 'View market data',
          url: '/markets',
          icons: [{ src: '/icons/markets-96x96.png', sizes: '96x96' }]
        },
        {
          name: 'Trade',
          short_name: 'Trade',
          description: 'Execute trades',
          url: '/trade',
          icons: [{ src: '/icons/trade-96x96.png', sizes: '96x96' }]
        }
      ],
      
      categories: ['finance', 'business', 'productivity'],
      
      screenshots: [
        {
          src: '/screenshots/portfolio-mobile.png',
          type: 'image/png',
          sizes: '540x720'
        },
        {
          src: '/screenshots/markets-mobile.png',
          type: 'image/png',
          sizes: '540x720'
        }
      ]
    };
  }

  generateOfflinePage() {
    return `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CryptoAI - Offline</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            margin: 0;
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
        }
        .offline-container {
            max-width: 400px;
            padding: 40px 20px;
        }
        .offline-icon {
            font-size: 64px;
            margin-bottom: 20px;
        }
        h1 {
            margin-bottom: 16px;
            font-size: 24px;
        }
        p {
            margin-bottom: 24px;
            opacity: 0.9;
            line-height: 1.5;
        }
        .retry-button {
            background: rgba(255, 255, 255, 0.2);
            border: 2px solid rgba(255, 255, 255, 0.3);
            color: white;
            padding: 12px 24px;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .retry-button:hover {
            background: rgba(255, 255, 255, 0.3);
            border-color: rgba(255, 255, 255, 0.5);
        }
        .cached-data {
            margin-top: 40px;
            padding: 20px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            text-align: left;
        }
    </style>
</head>
<body>
    <div class="offline-container">
        <div class="offline-icon">📱</div>
        <h1>You're Offline</h1>
        <p>
            CryptoAI is currently offline. Check your internet connection and try again.
            Some cached data may still be available below.
        </p>
        <button class="retry-button" onclick="window.location.reload()">
            Retry Connection
        </button>
        
        <div class="cached-data">
            <h3>📊 Last Known Portfolio</h3>
            <p><strong>Total Value:</strong> $25,750.50</p>
            <p><strong>24h Change:</strong> +$450.25 (+1.78%)</p>
            <p><strong>Last Update:</strong> <span id="lastUpdate"></span></p>
        </div>
    </div>

    <script>
        // Show last update time
        document.getElementById('lastUpdate').textContent = 
            new Date().toLocaleString();
        
        // Auto-retry connection every 30 seconds
        setInterval(() => {
            if (navigator.onLine) {
                window.location.reload();
            }
        }, 30000);
        
        // Listen for online event
        window.addEventListener('online', () => {
            window.location.reload();
        });
    </script>
</body>
</html>
    `.trim();
  }

  async sendPushNotification(userId, payload) {
    const subscription = this.pushSubscriptions.get(userId);
    
    if (!subscription || !subscription.active) {
      throw new Error('No active push subscription found for user');
    }

    // In a real implementation, you would use a library like web-push
    // to send the actual push notification
    console.log(`📲 Sending push notification to ${userId}:`, payload);
    
    // Mock successful send
    return {
      success: true,
      messageId: `msg_${Date.now()}`,
      timestamp: new Date().toISOString()
    };
  }

  // Utility methods
  formatPrice(price) {
    if (price >= 1000) {
      return price.toLocaleString('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 2
      });
    } else {
      return price.toLocaleString('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 4
      });
    }
  }

  formatPercentage(percent) {
    const sign = percent >= 0 ? '+' : '';
    return `${sign}${percent.toFixed(2)}%`;
  }

  getTimeframeMs(timeframe) {
    const timeframes = {
      '1m': 60 * 1000,
      '5m': 5 * 60 * 1000,
      '15m': 15 * 60 * 1000,
      '1h': 60 * 60 * 1000,
      '4h': 4 * 60 * 60 * 1000,
      '1d': 24 * 60 * 60 * 1000
    };
    
    return timeframes[timeframe] || timeframes['1h'];
  }

  getRouter() {
    return this.router;
  }

  getStatus() {
    return {
      isInitialized: this.isInitialized,
      pushSubscriptions: this.pushSubscriptions.size,
      mobileConfig: this.mobileConfig,
      features: {
        offlineSupport: true,
        pushNotifications: true,
        quickTrade: true,
        optimizedCharts: true,
        responsiveDesign: true
      }
    };
  }
}

module.exports = MobilePWAEngine;