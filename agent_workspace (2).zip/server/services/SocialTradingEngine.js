const EventEmitter = require('events');

/**
 * Social Trading & Copy Trading Engine
 * Enables following successful traders and sharing strategies
 */
class SocialTradingEngine extends EventEmitter {
  constructor() {
    super();
    this.traders = new Map();
    this.strategies = new Map();
    this.copyTrades = new Map();
    this.leaderboard = [];
    this.socialFeed = [];
    this.following = new Map();
    this.followers = new Map();
    this.isInitialized = false;
  }

  async initialize() {
    console.log('🔄 Initializing Social Trading Engine...');
    
    // Initialize leaderboard
    await this.updateLeaderboard();
    
    // Start periodic updates
    this.startPeriodicUpdates();
    
    this.isInitialized = true;
    console.log('✅ Social Trading Engine initialized');
  }

  /**
   * Trader Profile Management
   */
  async createTraderProfile(userId, profileData) {
    const trader = {
      id: userId,
      username: profileData.username,
      displayName: profileData.displayName,
      avatar: profileData.avatar,
      bio: profileData.bio,
      experience: profileData.experience || 'BEGINNER',
      riskProfile: profileData.riskProfile || 'MEDIUM',
      specialties: profileData.specialties || [],
      
      // Performance metrics
      performance: {
        totalReturn: 0,
        monthlyReturn: 0,
        winRate: 0,
        sharpeRatio: 0,
        maxDrawdown: 0,
        averageHoldTime: 0,
        totalTrades: 0,
        profitableTrades: 0
      },
      
      // Social metrics
      social: {
        followers: 0,
        following: 0,
        copiers: 0,
        likes: 0,
        posts: 0,
        reputation: 1000 // Starting reputation
      },
      
      // Settings
      settings: {
        publicProfile: profileData.publicProfile !== false,
        allowCopying: profileData.allowCopying !== false,
        shareStrategies: profileData.shareStrategies !== false,
        autoShareTrades: profileData.autoShareTrades || false
      },
      
      // Verification
      verification: {
        email: false,
        phone: false,
        identity: false,
        exchange: false
      },
      
      // Timestamps
      created: new Date().toISOString(),
      lastActive: new Date().toISOString()
    };

    this.traders.set(userId, trader);
    
    console.log(`👤 Trader profile created: ${trader.username}`);
    
    this.emit('traderProfileCreated', trader);
    return trader;
  }

  async updateTraderPerformance(userId, performanceData) {
    const trader = this.traders.get(userId);
    if (!trader) return false;

    // Update performance metrics
    Object.assign(trader.performance, performanceData);
    
    // Update last active
    trader.lastActive = new Date().toISOString();

    // Recalculate reputation
    trader.social.reputation = this.calculateReputation(trader);

    this.emit('traderPerformanceUpdated', trader);
    return true;
  }

  calculateReputation(trader) {
    const perf = trader.performance;
    const social = trader.social;
    
    let reputation = 1000; // Base reputation
    
    // Performance factors
    reputation += Math.min(perf.totalReturn * 10, 500); // Max 500 from returns
    reputation += Math.min(perf.winRate * 5, 200); // Max 200 from win rate
    reputation += Math.min(perf.sharpeRatio * 100, 300); // Max 300 from Sharpe
    reputation -= Math.max(perf.maxDrawdown * 10, 0); // Penalty for drawdown
    
    // Social factors
    reputation += Math.min(social.followers * 2, 200); // Max 200 from followers
    reputation += Math.min(social.likes, 100); // Max 100 from likes
    reputation += Math.min(social.copiers * 5, 250); // Max 250 from copiers
    
    // Experience bonus
    const experienceBonus = {
      'BEGINNER': 0,
      'INTERMEDIATE': 50,
      'ADVANCED': 100,
      'EXPERT': 200,
      'MASTER': 500
    };
    reputation += experienceBonus[trader.experience] || 0;

    return Math.max(reputation, 0); // Can't go below 0
  }

  /**
   * Strategy Sharing
   */
  async shareStrategy(userId, strategyData) {
    const trader = this.traders.get(userId);
    if (!trader || !trader.settings.shareStrategies) {
      throw new Error('Trader not found or strategy sharing disabled');
    }

    const strategy = {
      id: `strategy_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      authorId: userId,
      authorName: trader.username,
      
      name: strategyData.name,
      description: strategyData.description,
      category: strategyData.category,
      riskLevel: strategyData.riskLevel,
      timeframe: strategyData.timeframe,
      
      // Strategy details
      rules: strategyData.rules,
      indicators: strategyData.indicators,
      entryConditions: strategyData.entryConditions,
      exitConditions: strategyData.exitConditions,
      riskManagement: strategyData.riskManagement,
      
      // Performance
      backtestResults: strategyData.backtestResults,
      livePerformance: {
        totalReturn: 0,
        winRate: 0,
        sharpeRatio: 0,
        maxDrawdown: 0,
        totalTrades: 0
      },
      
      // Social metrics
      social: {
        likes: 0,
        comments: [],
        shares: 0,
        subscribers: 0,
        rating: 0,
        ratingCount: 0
      },
      
      // Pricing (if premium)
      pricing: {
        free: strategyData.free !== false,
        price: strategyData.price || 0,
        subscriptionType: strategyData.subscriptionType || 'ONE_TIME'
      },
      
      created: new Date().toISOString(),
      updated: new Date().toISOString()
    };

    this.strategies.set(strategy.id, strategy);
    
    // Add to social feed
    this.addToSocialFeed({
      type: 'STRATEGY_SHARED',
      userId: userId,
      username: trader.username,
      content: {
        strategyId: strategy.id,
        strategyName: strategy.name,
        description: strategy.description
      },
      timestamp: new Date().toISOString()
    });

    console.log(`📊 Strategy shared: ${strategy.name} by ${trader.username}`);
    
    this.emit('strategyShared', strategy);
    return strategy.id;
  }

  async subscribeToStrategy(userId, strategyId) {
    const strategy = this.strategies.get(strategyId);
    const trader = this.traders.get(userId);
    
    if (!strategy || !trader) {
      throw new Error('Strategy or trader not found');
    }

    if (!strategy.pricing.free && strategy.pricing.price > 0) {
      // Handle payment logic here
      console.log(`💰 Payment required: $${strategy.pricing.price} for ${strategy.name}`);
    }

    // Add to subscriber's strategies
    if (!trader.subscribedStrategies) {
      trader.subscribedStrategies = [];
    }
    
    if (!trader.subscribedStrategies.includes(strategyId)) {
      trader.subscribedStrategies.push(strategyId);
      strategy.social.subscribers++;
      
      console.log(`📥 ${trader.username} subscribed to strategy: ${strategy.name}`);
    }

    return true;
  }

  /**
   * Copy Trading System
   */
  async startCopyTrading(followerId, traderId, settings = {}) {
    const follower = this.traders.get(followerId);
    const leader = this.traders.get(traderId);
    
    if (!follower || !leader) {
      throw new Error('Trader not found');
    }

    if (!leader.settings.allowCopying) {
      throw new Error('This trader does not allow copying');
    }

    const copyTrade = {
      id: `copy_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      followerId: followerId,
      traderId: traderId,
      
      settings: {
        copyRatio: settings.copyRatio || 0.1, // Copy 10% of leader's position size
        maxCopyAmount: settings.maxCopyAmount || 1000, // Max $1000 per trade
        stopCopyingLoss: settings.stopCopyingLoss || -20, // Stop if -20% portfolio loss
        delaySeconds: settings.delaySeconds || 0, // No delay by default
        copyOpenTrades: settings.copyOpenTrades || false,
        
        // Filters
        enabledAssets: settings.enabledAssets || [], // Empty = all assets
        disabledAssets: settings.disabledAssets || [],
        maxRiskPerTrade: settings.maxRiskPerTrade || 5, // Max 5% risk per trade
        
        // Risk management
        useStopLoss: settings.useStopLoss !== false,
        useTakeProfit: settings.useTakeProfit !== false,
        maxDrawdown: settings.maxDrawdown || 15 // Stop copying at 15% drawdown
      },
      
      performance: {
        totalReturn: 0,
        totalTrades: 0,
        profitableTrades: 0,
        totalCopied: 0,
        averageDelay: 0
      },
      
      status: 'ACTIVE',
      created: new Date().toISOString(),
      lastCopy: null
    };

    this.copyTrades.set(copyTrade.id, copyTrade);

    // Update social metrics
    if (!this.following.has(followerId)) {
      this.following.set(followerId, new Set());
    }
    this.following.get(followerId).add(traderId);

    if (!this.followers.has(traderId)) {
      this.followers.set(traderId, new Set());
    }
    this.followers.get(traderId).add(followerId);

    // Update trader metrics
    leader.social.copiers++;
    follower.social.following++;

    console.log(`🔄 Copy trading started: ${follower.username} → ${leader.username}`);
    
    this.emit('copyTradingStarted', copyTrade);
    return copyTrade.id;
  }

  async executeCopyTrade(leaderTrade, copyTradeSettings) {
    const copyTrade = this.copyTrades.get(copyTradeSettings.id);
    if (!copyTrade || copyTrade.status !== 'ACTIVE') {
      return false;
    }

    // Apply filters
    if (!this.shouldCopyTrade(leaderTrade, copyTrade.settings)) {
      return false;
    }

    // Calculate copy size
    const copySize = this.calculateCopySize(leaderTrade, copyTrade.settings);
    if (copySize <= 0) {
      return false;
    }

    // Apply delay if configured
    if (copyTrade.settings.delaySeconds > 0) {
      setTimeout(() => {
        this.executeCopyTradeDelayed(leaderTrade, copyTrade, copySize);
      }, copyTrade.settings.delaySeconds * 1000);
    } else {
      await this.executeCopyTradeDelayed(leaderTrade, copyTrade, copySize);
    }

    return true;
  }

  shouldCopyTrade(leaderTrade, settings) {
    // Check asset filters
    if (settings.enabledAssets.length > 0 && !settings.enabledAssets.includes(leaderTrade.asset)) {
      return false;
    }
    
    if (settings.disabledAssets.includes(leaderTrade.asset)) {
      return false;
    }

    // Check risk per trade
    if (leaderTrade.riskPercentage > settings.maxRiskPerTrade) {
      return false;
    }

    return true;
  }

  calculateCopySize(leaderTrade, settings) {
    let copySize = leaderTrade.size * settings.copyRatio;
    
    // Apply maximum copy amount
    const maxSize = settings.maxCopyAmount / leaderTrade.price;
    copySize = Math.min(copySize, maxSize);
    
    return copySize;
  }

  async executeCopyTradeDelayed(leaderTrade, copyTrade, copySize) {
    try {
      // This would integrate with the actual trading system
      const copyTradeResult = {
        id: `copy_trade_${Date.now()}`,
        originalTradeId: leaderTrade.id,
        copyTradeId: copyTrade.id,
        asset: leaderTrade.asset,
        action: leaderTrade.action,
        size: copySize,
        price: leaderTrade.price, // Market price at execution time
        timestamp: new Date().toISOString()
      };

      // Update copy trade performance
      copyTrade.performance.totalTrades++;
      copyTrade.performance.totalCopied += copySize * leaderTrade.price;
      copyTrade.lastCopy = copyTradeResult.timestamp;

      console.log(`📋 Copy trade executed: ${copyTrade.followerId} copied ${leaderTrade.action} ${copySize} ${leaderTrade.asset}`);
      
      this.emit('copyTradeExecuted', copyTradeResult);
      
    } catch (error) {
      console.error('Copy trade execution failed:', error);
      this.emit('copyTradeFailed', { copyTrade, leaderTrade, error: error.message });
    }
  }

  /**
   * Social Feed & Communication
   */
  addToSocialFeed(post) {
    const feedPost = {
      id: `post_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      ...post,
      likes: 0,
      comments: [],
      shares: 0
    };

    this.socialFeed.unshift(feedPost);

    // Keep only last 1000 posts
    if (this.socialFeed.length > 1000) {
      this.socialFeed = this.socialFeed.slice(0, 1000);
    }

    this.emit('socialFeedUpdated', feedPost);
    return feedPost.id;
  }

  async shareTradeResult(userId, trade) {
    const trader = this.traders.get(userId);
    if (!trader || !trader.settings.autoShareTrades) {
      return false;
    }

    const profit = trade.pnl;
    const profitPercentage = (profit / trade.initialValue) * 100;

    // Only share profitable trades or significant losses (for transparency)
    if (profitPercentage < -10 || profitPercentage > 5) {
      this.addToSocialFeed({
        type: 'TRADE_RESULT',
        userId: userId,
        username: trader.username,
        content: {
          asset: trade.asset,
          action: trade.action,
          profit: profit,
          profitPercentage: profitPercentage,
          duration: trade.duration,
          strategy: trade.strategy
        },
        timestamp: new Date().toISOString()
      });
    }

    return true;
  }

  /**
   * Leaderboard & Rankings
   */
  async updateLeaderboard() {
    const traders = Array.from(this.traders.values())
      .filter(trader => trader.settings.publicProfile && trader.performance.totalTrades > 10);

    // Calculate composite score for ranking
    traders.forEach(trader => {
      trader.compositeScore = this.calculateCompositeScore(trader);
    });

    // Sort by different criteria
    this.leaderboard = {
      overall: traders.sort((a, b) => b.compositeScore - a.compositeScore).slice(0, 100),
      return: traders.sort((a, b) => b.performance.totalReturn - a.performance.totalReturn).slice(0, 50),
      winRate: traders.sort((a, b) => b.performance.winRate - a.performance.winRate).slice(0, 50),
      sharpe: traders.sort((a, b) => b.performance.sharpeRatio - a.performance.sharpeRatio).slice(0, 50),
      lowDrawdown: traders.sort((a, b) => a.performance.maxDrawdown - b.performance.maxDrawdown).slice(0, 50),
      followers: traders.sort((a, b) => b.social.followers - a.social.followers).slice(0, 50),
      reputation: traders.sort((a, b) => b.social.reputation - a.social.reputation).slice(0, 50)
    };

    console.log(`📊 Leaderboard updated: ${traders.length} traders ranked`);
    this.emit('leaderboardUpdated', this.leaderboard);
  }

  calculateCompositeScore(trader) {
    const perf = trader.performance;
    const social = trader.social;
    
    // Weighted composite score
    let score = 0;
    
    // Performance (70% weight)
    score += perf.totalReturn * 0.3; // 30% from returns
    score += perf.winRate * 0.2; // 20% from win rate
    score += perf.sharpeRatio * 10 * 0.1; // 10% from Sharpe ratio
    score -= perf.maxDrawdown * 0.1; // 10% penalty for drawdown
    
    // Social (20% weight)
    score += Math.log(social.followers + 1) * 0.1; // 10% from followers (log scale)
    score += Math.log(social.copiers + 1) * 0.1; // 10% from copiers (log scale)
    
    // Reputation (10% weight)
    score += (social.reputation / 1000) * 0.1; // 10% from reputation

    return score;
  }

  /**
   * Discovery & Recommendations
   */
  async discoverTraders(userId, preferences = {}) {
    const user = this.traders.get(userId);
    if (!user) return [];

    let candidates = Array.from(this.traders.values())
      .filter(trader => trader.id !== userId && trader.settings.publicProfile);

    // Apply filters
    if (preferences.riskLevel) {
      candidates = candidates.filter(t => t.riskProfile === preferences.riskLevel);
    }

    if (preferences.experience) {
      candidates = candidates.filter(t => t.experience === preferences.experience);
    }

    if (preferences.specialties && preferences.specialties.length > 0) {
      candidates = candidates.filter(t => 
        t.specialties.some(s => preferences.specialties.includes(s))
      );
    }

    // Score and rank candidates
    candidates.forEach(trader => {
      trader.discoveryScore = this.calculateDiscoveryScore(trader, user, preferences);
    });

    // Sort by discovery score
    candidates.sort((a, b) => b.discoveryScore - a.discoveryScore);

    return candidates.slice(0, 20); // Return top 20 recommendations
  }

  calculateDiscoveryScore(candidate, user, preferences) {
    let score = candidate.compositeScore;

    // Boost score based on user preferences
    if (candidate.riskProfile === user.riskProfile) {
      score += 10;
    }

    if (candidate.specialties.some(s => user.specialties.includes(s))) {
      score += 15;
    }

    // Recent activity bonus
    const lastActive = new Date(candidate.lastActive);
    const daysSinceActive = (Date.now() - lastActive.getTime()) / (1000 * 60 * 60 * 24);
    if (daysSinceActive < 7) {
      score += 5;
    }

    return score;
  }

  /**
   * Periodic Updates
   */
  startPeriodicUpdates() {
    // Update leaderboard every hour
    setInterval(() => {
      this.updateLeaderboard();
    }, 60 * 60 * 1000);

    // Clean old social feed posts every 6 hours
    setInterval(() => {
      const cutoff = Date.now() - (7 * 24 * 60 * 60 * 1000); // 7 days ago
      this.socialFeed = this.socialFeed.filter(post => 
        new Date(post.timestamp).getTime() > cutoff
      );
    }, 6 * 60 * 60 * 1000);
  }

  /**
   * Analytics & Status
   */
  getStatus() {
    return {
      isInitialized: this.isInitialized,
      totalTraders: this.traders.size,
      publicTraders: Array.from(this.traders.values()).filter(t => t.settings.publicProfile).length,
      totalStrategies: this.strategies.size,
      activeCopyTrades: Array.from(this.copyTrades.values()).filter(ct => ct.status === 'ACTIVE').length,
      socialFeedPosts: this.socialFeed.length,
      leaderboardSize: this.leaderboard.overall?.length || 0
    };
  }

  getSocialAnalytics() {
    const traders = Array.from(this.traders.values());
    const strategies = Array.from(this.strategies.values());
    const copyTrades = Array.from(this.copyTrades.values());

    return {
      traderStats: {
        total: traders.length,
        verified: traders.filter(t => t.verification.identity).length,
        byExperience: this.groupBy(traders, 'experience'),
        byRiskProfile: this.groupBy(traders, 'riskProfile')
      },
      strategyStats: {
        total: strategies.length,
        byCategory: this.groupBy(strategies, 'category'),
        byRiskLevel: this.groupBy(strategies, 'riskLevel'),
        totalSubscribers: strategies.reduce((sum, s) => sum + s.social.subscribers, 0)
      },
      copyTradingStats: {
        total: copyTrades.length,
        active: copyTrades.filter(ct => ct.status === 'ACTIVE').length,
        totalVolume: copyTrades.reduce((sum, ct) => sum + ct.performance.totalCopied, 0)
      },
      engagement: {
        totalPosts: this.socialFeed.length,
        totalLikes: this.socialFeed.reduce((sum, post) => sum + post.likes, 0),
        totalComments: this.socialFeed.reduce((sum, post) => sum + post.comments.length, 0)
      }
    };
  }

  groupBy(array, key) {
    return array.reduce((groups, item) => {
      const group = item[key];
      groups[group] = (groups[group] || 0) + 1;
      return groups;
    }, {});
  }
}

module.exports = SocialTradingEngine;