/**
 * FirstTimeSetupWizard.js - CryptoAI Platform V5.0
 * Interactive Setup Wizard for Easy Platform Configuration
 * Guides users through API key setup, trading preferences, and initial configuration
 */

const readline = require('readline');
const APIKeyManager = require('./APIKeyManager');

class FirstTimeSetupWizard {
    constructor() {
        this.apiKeyManager = new APIKeyManager();
        this.rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout
        });
        
        this.setupData = {
            exchanges: [],
            tradingSettings: {},
            userPreferences: {}
        };
    }

    async startSetup() {
        try {
            console.clear();
            this.showWelcomeBanner();
            
            console.log('🎯 Welcome to CryptoAI Platform V5.0 Setup Wizard!');
            console.log('This wizard will help you configure your platform in just a few steps.\n');

            // Step 1: Welcome and Overview
            await this.showSetupOverview();
            
            // Step 2: Exchange Configuration
            await this.setupExchanges();
            
            // Step 3: Trading Settings
            await this.setupTradingPreferences();
            
            // Step 4: Security Settings
            await this.setupSecurityPreferences();
            
            // Step 5: Generate Configuration
            await this.generateConfiguration();
            
            // Step 6: Final Setup
            await this.completeSetup();
            
            this.rl.close();
            
        } catch (error) {
            console.error('❌ Setup wizard error:', error.message);
            this.rl.close();
        }
    }

    showWelcomeBanner() {
        console.log(`
╔═══════════════════════════════════════════════════════════════╗
║                  🚀 CryptoAI Platform V5.0                   ║
║                   100% Automated Era                         ║
║                                                               ║
║           Easy Setup Wizard - First Time Configuration       ║
╚═══════════════════════════════════════════════════════════════╝
        `);
    }

    async showSetupOverview() {
        console.log('📋 SETUP OVERVIEW:');
        console.log('  1️⃣  Exchange API Configuration');
        console.log('  2️⃣  Trading Preferences Setup');
        console.log('  3️⃣  Security Configuration');
        console.log('  4️⃣  Generate Environment Files');
        console.log('  5️⃣  Complete Setup & Launch\n');
        
        const proceed = await this.askQuestion('Ready to begin? (y/n): ');
        if (proceed.toLowerCase() !== 'y' && proceed.toLowerCase() !== 'yes') {
            console.log('Setup cancelled. You can run this wizard anytime with: npm run setup:wizard');
            process.exit(0);
        }
        
        console.log('\n' + '='.repeat(60) + '\n');
    }

    async setupExchanges() {
        console.log('🏦 STEP 1: EXCHANGE API CONFIGURATION\n');
        console.log('Configure your cryptocurrency exchange API credentials.');
        console.log('You can add multiple exchanges or skip and add them later.\n');
        
        this.showSupportedExchanges();
        
        let addingExchanges = true;
        
        while (addingExchanges) {
            const exchangeName = await this.askQuestion('\nWhich exchange would you like to configure? (or "skip"/"done"): ');
            
            if (exchangeName.toLowerCase() === 'skip' || exchangeName.toLowerCase() === 'done') {
                addingExchanges = false;
                continue;
            }

            const normalizedName = exchangeName.toLowerCase().replace(/\s+/g, '_');
            
            if (this.apiKeyManager.supportedExchanges[normalizedName]) {
                await this.configureExchange(normalizedName);
            } else {
                console.log('❌ Unsupported exchange. Please choose from the list above.');
            }
            
            const addMore = await this.askQuestion('\nWould you like to add another exchange? (y/n): ');
            if (addMore.toLowerCase() !== 'y' && addMore.toLowerCase() !== 'yes') {
                addingExchanges = false;
            }
        }
        
        console.log('\n' + '='.repeat(60) + '\n');
    }

    showSupportedExchanges() {
        console.log('📈 SUPPORTED EXCHANGES:');
        Object.entries(this.apiKeyManager.supportedExchanges).forEach(([key, info]) => {
            console.log(`  ${info.icon} ${info.name} (${key})`);
        });
    }

    async configureExchange(exchangeKey) {
        const exchangeInfo = this.apiKeyManager.supportedExchanges[exchangeKey];
        console.log(`\n🔧 Configuring ${exchangeInfo.icon} ${exchangeInfo.name}:`);
        console.log(`Required fields: ${exchangeInfo.fields.join(', ')}\n`);
        
        const credentials = {};
        
        for (const field of exchangeInfo.fields) {
            const prompt = field === 'secretKey' ? 
                `Enter ${field} (input will be hidden): ` : 
                `Enter ${field}: `;
                
            credentials[field] = await this.askQuestion(prompt, field === 'secretKey');
        }
        
        console.log(`\n🔄 Adding ${exchangeInfo.name} credentials...`);
        
        const result = await this.apiKeyManager.addExchangeCredentials(exchangeKey, credentials);
        
        if (result.success) {
            console.log(`✅ ${result.message}`);
            this.setupData.exchanges.push({
                exchange: exchangeKey,
                name: exchangeInfo.name,
                icon: exchangeInfo.icon,
                validated: result.validated
            });
        } else {
            console.log(`❌ Failed to add ${exchangeInfo.name}: ${result.error}`);
        }
    }

    async setupTradingPreferences() {
        console.log('⚙️ STEP 2: TRADING PREFERENCES SETUP\n');
        console.log('Configure your automated trading preferences and risk management.\n');
        
        // Auto trading enablement
        const enableAutoTrading = await this.askQuestion('Enable automated trading? (y/n): ');
        this.setupData.tradingSettings.autoTradingEnabled = 
            enableAutoTrading.toLowerCase() === 'y' || enableAutoTrading.toLowerCase() === 'yes';
        
        if (this.setupData.tradingSettings.autoTradingEnabled) {
            // Risk level
            console.log('\n📊 Risk Level Options:');
            console.log('  1. Conservative (Low risk, stable gains)');
            console.log('  2. Moderate (Balanced risk/reward)');
            console.log('  3. Aggressive (High risk, potential high returns)');
            
            const riskChoice = await this.askQuestion('\nSelect risk level (1-3): ');
            const riskLevels = { '1': 'conservative', '2': 'moderate', '3': 'aggressive' };
            this.setupData.tradingSettings.riskLevel = riskLevels[riskChoice] || 'moderate';
            
            // Maximum daily loss
            const maxLoss = await this.askQuestion('Maximum daily loss percentage (1-20): ');
            this.setupData.tradingSettings.maxDailyLoss = Math.min(Math.max(parseFloat(maxLoss) || 5, 1), 20);
            
            // Preferred quote currency
            console.log('\n💰 Preferred quote currency options: USDT, BUSD, USDC, BTC, ETH');
            const quoteCurrency = await this.askQuestion('Preferred quote currency (default: USDT): ');
            this.setupData.tradingSettings.preferredQuoteCurrency = quoteCurrency.toUpperCase() || 'USDT';
            
        } else {
            console.log('📝 Automated trading disabled. You can enable it later in settings.');
            this.setupData.tradingSettings.riskLevel = 'moderate';
            this.setupData.tradingSettings.maxDailyLoss = 5;
            this.setupData.tradingSettings.preferredQuoteCurrency = 'USDT';
        }
        
        console.log('\n✅ Trading preferences configured successfully!');
        console.log('\n' + '='.repeat(60) + '\n');
    }

    async setupSecurityPreferences() {
        console.log('🔐 STEP 3: SECURITY CONFIGURATION\n');
        console.log('Configure security settings for your platform.\n');
        
        // Notification preferences
        const enableNotifications = await this.askQuestion('Enable trading notifications? (y/n): ');
        this.setupData.userPreferences.notificationsEnabled = 
            enableNotifications.toLowerCase() === 'y' || enableNotifications.toLowerCase() === 'yes';
        
        if (this.setupData.userPreferences.notificationsEnabled) {
            const email = await this.askQuestion('Email for notifications (optional): ');
            this.setupData.userPreferences.notificationEmail = email;
        }
        
        // Two-factor authentication
        const enable2FA = await this.askQuestion('Enable two-factor authentication? (recommended) (y/n): ');
        this.setupData.userPreferences.twoFactorEnabled = 
            enable2FA.toLowerCase() === 'y' || enable2FA.toLowerCase() === 'yes';
        
        // API access control
        const enableAPIAccess = await this.askQuestion('Enable external API access? (y/n): ');
        this.setupData.userPreferences.apiAccessEnabled = 
            enableAPIAccess.toLowerCase() === 'y' || enableAPIAccess.toLowerCase() === 'yes';
        
        console.log('\n✅ Security preferences configured successfully!');
        console.log('\n' + '='.repeat(60) + '\n');
    }

    async generateConfiguration() {
        console.log('⚙️ STEP 4: GENERATING CONFIGURATION FILES\n');
        console.log('🔄 Updating trading settings...');
        
        // Update API key manager with trading settings
        const updateResult = this.apiKeyManager.updateTradingSettings(this.setupData.tradingSettings);
        
        if (updateResult.success) {
            console.log('✅ Trading settings updated successfully');
        } else {
            console.log('❌ Warning: Failed to update trading settings');
        }
        
        console.log('🔄 Generating environment configuration...');
        
        // Generate .env file
        const envResult = this.apiKeyManager.generateEnvFile();
        
        if (envResult.success) {
            console.log('✅ Environment file generated successfully');
            console.log(`📄 Configuration saved to: ${envResult.path}`);
        } else {
            console.log('❌ Warning: Failed to generate environment file');
        }
        
        console.log('\n✅ Configuration files generated successfully!');
        console.log('\n' + '='.repeat(60) + '\n');
    }

    async completeSetup() {
        console.log('🎉 STEP 5: SETUP COMPLETE!\n');
        
        // Show setup summary
        this.showSetupSummary();
        
        console.log('\n🚀 NEXT STEPS:');
        console.log('  1. Review your configuration files');
        console.log('  2. Start the platform with: npm run start:v5');
        console.log('  3. Access the dashboard at: http://localhost:3000');
        console.log('  4. Monitor your trading status in real-time\n');
        
        const startNow = await this.askQuestion('Would you like to start the platform now? (y/n): ');
        
        if (startNow.toLowerCase() === 'y' || startNow.toLowerCase() === 'yes') {
            console.log('\n🚀 Starting CryptoAI Platform V5.0...\n');
            console.log('Platform will start in a new process.');
            console.log('You can access the dashboard at: http://localhost:3000');
            console.log('Use Ctrl+C to stop the platform when needed.\n');
            
            // Create start script
            this.createQuickStartScript();
            
            return true;
        } else {
            console.log('\n📝 Setup completed successfully!');
            console.log('Run "npm run start:v5" when you\'re ready to start the platform.');
            return false;
        }
    }

    showSetupSummary() {
        console.log('📊 SETUP SUMMARY:');
        console.log('─'.repeat(40));
        
        console.log(`🏦 Exchanges Configured: ${this.setupData.exchanges.length}`);
        this.setupData.exchanges.forEach(exchange => {
            const status = exchange.validated ? '✅' : '⚠️';
            console.log(`  ${exchange.icon} ${exchange.name} ${status}`);
        });
        
        console.log(`\n⚙️ Trading Settings:`);
        console.log(`  Auto Trading: ${this.setupData.tradingSettings.autoTradingEnabled ? '✅ Enabled' : '❌ Disabled'}`);
        console.log(`  Risk Level: ${this.setupData.tradingSettings.riskLevel}`);
        console.log(`  Max Daily Loss: ${this.setupData.tradingSettings.maxDailyLoss}%`);
        console.log(`  Quote Currency: ${this.setupData.tradingSettings.preferredQuoteCurrency}`);
        
        console.log(`\n🔐 Security Settings:`);
        console.log(`  Notifications: ${this.setupData.userPreferences.notificationsEnabled ? '✅ Enabled' : '❌ Disabled'}`);
        console.log(`  Two-Factor Auth: ${this.setupData.userPreferences.twoFactorEnabled ? '✅ Enabled' : '❌ Disabled'}`);
        console.log(`  API Access: ${this.setupData.userPreferences.apiAccessEnabled ? '✅ Enabled' : '❌ Disabled'}`);
    }

    createQuickStartScript() {
        const quickStartContent = `#!/bin/bash
# CryptoAI Platform V5.0 - Quick Start Script
# Generated by Setup Wizard on ${new Date().toISOString()}

echo "🚀 Starting CryptoAI Platform V5.0 - 100% Automated Era"
echo "════════════════════════════════════════════════════════"

cd server
npm run start:v5

echo "Platform stopped. Thank you for using CryptoAI!"
`;

        require('fs').writeFileSync('/workspace/quick_start_v5.sh', quickStartContent);
        require('fs').chmodSync('/workspace/quick_start_v5.sh', 0o755);
        
        console.log('✅ Quick start script created: quick_start_v5.sh');
    }

    async askQuestion(question, hideInput = false) {
        return new Promise((resolve) => {
            if (hideInput) {
                // Hide input for sensitive data
                process.stdout.write(question);
                process.stdin.setRawMode(true);
                let input = '';
                
                process.stdin.on('data', function handler(char) {
                    char = char.toString();
                    
                    if (char === '\r' || char === '\n') {
                        process.stdin.setRawMode(false);
                        process.stdin.removeListener('data', handler);
                        process.stdout.write('\n');
                        resolve(input);
                    } else if (char === '\u0003') {
                        // Ctrl+C
                        process.exit();
                    } else if (char === '\u007f') {
                        // Backspace
                        if (input.length > 0) {
                            input = input.slice(0, -1);
                            process.stdout.write('\b \b');
                        }
                    } else {
                        input += char;
                        process.stdout.write('*');
                    }
                });
            } else {
                this.rl.question(question, resolve);
            }
        });
    }
}

// Export and self-executing capability
module.exports = FirstTimeSetupWizard;

// Allow direct execution
if (require.main === module) {
    const wizard = new FirstTimeSetupWizard();
    wizard.startSetup().catch(error => {
        console.error('❌ Setup failed:', error.message);
        process.exit(1);
    });
}
