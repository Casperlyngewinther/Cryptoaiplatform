const EventEmitter = require('events');

/**
 * Advanced Alert & Notification System
 * Provides intelligent monitoring, alerts, and multi-channel notifications
 */
class AdvancedAlertSystem extends EventEmitter {
  constructor() {
    super();
    this.alerts = new Map();
    this.notifications = new Map();
    this.channels = new Map();
    this.conditions = new Map();
    this.alertHistory = [];
    this.isInitialized = false;
  }

  async initialize() {
    console.log('🔄 Initializing Advanced Alert System...');
    
    // Initialize notification channels
    await this.setupNotificationChannels();
    
    // Setup default alert conditions
    await this.setupDefaultAlertConditions();
    
    // Start monitoring loop
    this.startMonitoring();
    
    this.isInitialized = true;
    console.log('✅ Advanced Alert System initialized');
  }

  async setupNotificationChannels() {
    // Email notifications
    this.channels.set('email', {
      type: 'EMAIL',
      enabled: process.env.EMAIL_ENABLED === 'true',
      config: {
        smtp_host: process.env.SMTP_HOST,
        smtp_port: process.env.SMTP_PORT,
        username: process.env.SMTP_USERNAME,
        password: process.env.SMTP_PASSWORD,
        from_email: process.env.FROM_EMAIL
      },
      rateLimit: 60000, // 1 minute between emails
      lastSent: 0
    });

    // SMS notifications
    this.channels.set('sms', {
      type: 'SMS',
      enabled: process.env.SMS_ENABLED === 'true',
      config: {
        service: process.env.SMS_SERVICE || 'twilio',
        api_key: process.env.SMS_API_KEY,
        api_secret: process.env.SMS_API_SECRET,
        from_number: process.env.FROM_PHONE_NUMBER
      },
      rateLimit: 300000, // 5 minutes between SMS
      lastSent: 0
    });

    // Slack notifications
    this.channels.set('slack', {
      type: 'SLACK',
      enabled: process.env.SLACK_ENABLED === 'true',
      config: {
        webhook_url: process.env.SLACK_WEBHOOK_URL,
        channel: process.env.SLACK_CHANNEL || '#trading-alerts',
        username: 'CryptoAI Bot'
      },
      rateLimit: 10000, // 10 seconds between Slack messages
      lastSent: 0
    });

    // Discord notifications
    this.channels.set('discord', {
      type: 'DISCORD',
      enabled: process.env.DISCORD_ENABLED === 'true',
      config: {
        webhook_url: process.env.DISCORD_WEBHOOK_URL,
        username: 'CryptoAI Bot',
        avatar_url: process.env.DISCORD_AVATAR_URL
      },
      rateLimit: 10000, // 10 seconds between Discord messages
      lastSent: 0
    });

    // Telegram notifications
    this.channels.set('telegram', {
      type: 'TELEGRAM',
      enabled: process.env.TELEGRAM_ENABLED === 'true',
      config: {
        bot_token: process.env.TELEGRAM_BOT_TOKEN,
        chat_id: process.env.TELEGRAM_CHAT_ID
      },
      rateLimit: 5000, // 5 seconds between Telegram messages
      lastSent: 0
    });

    // In-app notifications (WebSocket)
    this.channels.set('websocket', {
      type: 'WEBSOCKET',
      enabled: true,
      config: {},
      rateLimit: 1000, // 1 second between WebSocket notifications
      lastSent: 0
    });
  }

  async setupDefaultAlertConditions() {
    // Price movement alerts
    this.conditions.set('price_spike', {
      name: 'Price Spike Alert',
      description: 'Triggered when price increases rapidly',
      type: 'PRICE_MOVEMENT',
      parameters: {
        timeframe: '5m',
        threshold: 5.0, // 5% increase
        direction: 'UP'
      },
      severity: 'MEDIUM',
      enabled: true
    });

    this.conditions.set('price_crash', {
      name: 'Price Crash Alert',
      description: 'Triggered when price decreases rapidly',
      type: 'PRICE_MOVEMENT',
      parameters: {
        timeframe: '5m',
        threshold: -5.0, // 5% decrease
        direction: 'DOWN'
      },
      severity: 'HIGH',
      enabled: true
    });

    // Volume alerts
    this.conditions.set('volume_surge', {
      name: 'Volume Surge Alert',
      description: 'Triggered when trading volume spikes',
      type: 'VOLUME',
      parameters: {
        threshold_multiplier: 3.0, // 3x average volume
        timeframe: '15m'
      },
      severity: 'MEDIUM',
      enabled: true
    });

    // Portfolio alerts
    this.conditions.set('portfolio_loss', {
      name: 'Portfolio Loss Alert',
      description: 'Triggered when portfolio loses significant value',
      type: 'PORTFOLIO',
      parameters: {
        threshold: -10.0, // 10% portfolio loss
        timeframe: '1d'
      },
      severity: 'HIGH',
      enabled: true
    });

    this.conditions.set('profit_target', {
      name: 'Profit Target Alert',
      description: 'Triggered when profit target is reached',
      type: 'PORTFOLIO',
      parameters: {
        threshold: 20.0, // 20% profit
        timeframe: '1d'
      },
      severity: 'LOW',
      enabled: true
    });

    // Risk management alerts
    this.conditions.set('risk_limit_breach', {
      name: 'Risk Limit Breach',
      description: 'Triggered when risk limits are exceeded',
      type: 'RISK',
      parameters: {
        max_drawdown: 15.0, // 15% max drawdown
        var_threshold: 5.0, // 5% daily VaR
        concentration_risk: 25.0 // 25% max position size
      },
      severity: 'CRITICAL',
      enabled: true
    });

    // Technical indicator alerts
    this.conditions.set('rsi_oversold', {
      name: 'RSI Oversold Alert',
      description: 'Triggered when RSI indicates oversold conditions',
      type: 'TECHNICAL',
      parameters: {
        indicator: 'RSI',
        threshold: 30,
        direction: 'BELOW'
      },
      severity: 'LOW',
      enabled: true
    });

    this.conditions.set('rsi_overbought', {
      name: 'RSI Overbought Alert',
      description: 'Triggered when RSI indicates overbought conditions',
      type: 'TECHNICAL',
      parameters: {
        indicator: 'RSI',
        threshold: 70,
        direction: 'ABOVE'
      },
      severity: 'LOW',
      enabled: true
    });

    // System alerts
    this.conditions.set('exchange_disconnect', {
      name: 'Exchange Disconnection',
      description: 'Triggered when exchange connection is lost',
      type: 'SYSTEM',
      parameters: {
        timeout: 30000 // 30 seconds
      },
      severity: 'HIGH',
      enabled: true
    });

    this.conditions.set('ai_model_error', {
      name: 'AI Model Error',
      description: 'Triggered when AI model encounters errors',
      type: 'SYSTEM',
      parameters: {
        error_threshold: 3 // 3 consecutive errors
      },
      severity: 'MEDIUM',
      enabled: true
    });
  }

  /**
   * Create Custom Alert
   */
  async createAlert(alertConfig) {
    const alertId = `alert_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    const alert = {
      id: alertId,
      name: alertConfig.name,
      description: alertConfig.description,
      type: alertConfig.type,
      conditions: alertConfig.conditions,
      channels: alertConfig.channels || ['websocket'],
      severity: alertConfig.severity || 'MEDIUM',
      enabled: alertConfig.enabled !== false,
      created: new Date().toISOString(),
      lastTriggered: null,
      triggerCount: 0,
      snoozeUntil: null
    };

    this.alerts.set(alertId, alert);
    
    console.log(`📢 Alert created: ${alert.name} (${alertId})`);
    
    return alertId;
  }

  /**
   * Check Alert Conditions
   */
  async checkAlertConditions(marketData, portfolioData, systemData) {
    const currentTime = Date.now();
    const triggeredAlerts = [];

    // Check all active alerts
    for (const [alertId, alert] of this.alerts) {
      if (!alert.enabled || (alert.snoozeUntil && currentTime < alert.snoozeUntil)) {
        continue;
      }

      const isTriggered = await this.evaluateAlertCondition(alert, marketData, portfolioData, systemData);
      
      if (isTriggered) {
        await this.triggerAlert(alertId, alert, { marketData, portfolioData, systemData });
        triggeredAlerts.push(alertId);
      }
    }

    return triggeredAlerts;
  }

  async evaluateAlertCondition(alert, marketData, portfolioData, systemData) {
    try {
      switch (alert.type) {
        case 'PRICE_MOVEMENT':
          return this.checkPriceMovement(alert.conditions, marketData);
        
        case 'VOLUME':
          return this.checkVolumeCondition(alert.conditions, marketData);
        
        case 'PORTFOLIO':
          return this.checkPortfolioCondition(alert.conditions, portfolioData);
        
        case 'RISK':
          return this.checkRiskCondition(alert.conditions, portfolioData);
        
        case 'TECHNICAL':
          return this.checkTechnicalCondition(alert.conditions, marketData);
        
        case 'SYSTEM':
          return this.checkSystemCondition(alert.conditions, systemData);
        
        case 'CUSTOM':
          return this.checkCustomCondition(alert.conditions, { marketData, portfolioData, systemData });
        
        default:
          console.warn(`Unknown alert type: ${alert.type}`);
          return false;
      }
    } catch (error) {
      console.error(`Error evaluating alert condition for ${alert.id}:`, error);
      return false;
    }
  }

  checkPriceMovement(conditions, marketData) {
    if (!marketData.priceChange) return false;
    
    const change = marketData.priceChange.percentage;
    const threshold = conditions.threshold;
    
    if (conditions.direction === 'UP') {
      return change >= threshold;
    } else if (conditions.direction === 'DOWN') {
      return change <= threshold;
    } else {
      return Math.abs(change) >= Math.abs(threshold);
    }
  }

  checkVolumeCondition(conditions, marketData) {
    if (!marketData.volume || !marketData.averageVolume) return false;
    
    const volumeMultiplier = marketData.volume / marketData.averageVolume;
    return volumeMultiplier >= conditions.threshold_multiplier;
  }

  checkPortfolioCondition(conditions, portfolioData) {
    if (!portfolioData.performance) return false;
    
    const change = portfolioData.performance.totalReturn;
    return Math.abs(change) >= Math.abs(conditions.threshold);
  }

  checkRiskCondition(conditions, portfolioData) {
    if (!portfolioData.riskMetrics) return false;
    
    const metrics = portfolioData.riskMetrics;
    
    // Check max drawdown
    if (conditions.max_drawdown && metrics.maxDrawdown > conditions.max_drawdown) {
      return true;
    }
    
    // Check VaR
    if (conditions.var_threshold && Math.abs(metrics.valueAtRisk95) > conditions.var_threshold) {
      return true;
    }
    
    // Check concentration risk
    if (conditions.concentration_risk && portfolioData.maxPositionSize > conditions.concentration_risk) {
      return true;
    }
    
    return false;
  }

  checkTechnicalCondition(conditions, marketData) {
    if (!marketData.technicalIndicators) return false;
    
    const indicator = marketData.technicalIndicators[conditions.indicator];
    if (!indicator) return false;
    
    if (conditions.direction === 'ABOVE') {
      return indicator > conditions.threshold;
    } else if (conditions.direction === 'BELOW') {
      return indicator < conditions.threshold;
    }
    
    return false;
  }

  checkSystemCondition(conditions, systemData) {
    if (!systemData) return false;
    
    // Check exchange connectivity
    if (conditions.type === 'exchange_disconnect') {
      return systemData.exchangeConnections && 
             systemData.exchangeConnections.some(conn => !conn.connected);
    }
    
    // Check AI model health
    if (conditions.type === 'ai_model_error') {
      return systemData.aiModelErrors >= conditions.error_threshold;
    }
    
    return false;
  }

  /**
   * Trigger Alert
   */
  async triggerAlert(alertId, alert, context) {
    const notification = {
      id: `notif_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      alertId: alertId,
      alertName: alert.name,
      severity: alert.severity,
      message: await this.generateAlertMessage(alert, context),
      timestamp: new Date().toISOString(),
      channels: alert.channels,
      status: 'PENDING'
    };

    // Update alert statistics
    alert.lastTriggered = notification.timestamp;
    alert.triggerCount++;

    // Store notification
    this.notifications.set(notification.id, notification);

    // Add to history
    this.alertHistory.push({
      alertId: alertId,
      alertName: alert.name,
      severity: alert.severity,
      timestamp: notification.timestamp,
      message: notification.message
    });

    // Keep only last 1000 alerts in history
    if (this.alertHistory.length > 1000) {
      this.alertHistory = this.alertHistory.slice(-1000);
    }

    // Send notifications
    await this.sendNotification(notification);

    // Emit event
    this.emit('alertTriggered', {
      alert: alert,
      notification: notification,
      context: context
    });

    console.log(`🚨 Alert triggered: ${alert.name} (${alert.severity})`);
  }

  async generateAlertMessage(alert, context) {
    const timestamp = new Date().toISOString();
    
    let message = `🚨 ALERT: ${alert.name}\n`;
    message += `Severity: ${alert.severity}\n`;
    message += `Time: ${timestamp}\n`;
    message += `Description: ${alert.description}\n\n`;

    // Add context-specific information
    if (alert.type === 'PRICE_MOVEMENT' && context.marketData) {
      message += `Price Change: ${context.marketData.priceChange?.percentage?.toFixed(2)}%\n`;
      message += `Current Price: $${context.marketData.price?.toFixed(2)}\n`;
    }

    if (alert.type === 'PORTFOLIO' && context.portfolioData) {
      message += `Portfolio Value: $${context.portfolioData.totalValue?.toFixed(2)}\n`;
      message += `Total Return: ${context.portfolioData.performance?.totalReturn?.toFixed(2)}%\n`;
    }

    if (alert.type === 'RISK' && context.portfolioData) {
      message += `Max Drawdown: ${context.portfolioData.riskMetrics?.maxDrawdown?.toFixed(2)}%\n`;
      message += `VaR (95%): ${context.portfolioData.riskMetrics?.valueAtRisk95?.toFixed(2)}%\n`;
    }

    return message;
  }

  /**
   * Send Notification
   */
  async sendNotification(notification) {
    const results = [];

    for (const channelName of notification.channels) {
      const channel = this.channels.get(channelName);
      
      if (!channel || !channel.enabled) {
        continue;
      }

      // Check rate limiting
      const now = Date.now();
      if (now - channel.lastSent < channel.rateLimit) {
        console.log(`Rate limit reached for ${channelName}, skipping notification`);
        continue;
      }

      try {
        let result;
        
        switch (channel.type) {
          case 'EMAIL':
            result = await this.sendEmailNotification(channel, notification);
            break;
          case 'SMS':
            result = await this.sendSMSNotification(channel, notification);
            break;
          case 'SLACK':
            result = await this.sendSlackNotification(channel, notification);
            break;
          case 'DISCORD':
            result = await this.sendDiscordNotification(channel, notification);
            break;
          case 'TELEGRAM':
            result = await this.sendTelegramNotification(channel, notification);
            break;
          case 'WEBSOCKET':
            result = await this.sendWebSocketNotification(channel, notification);
            break;
        }

        if (result.success) {
          channel.lastSent = now;
        }

        results.push({
          channel: channelName,
          success: result.success,
          message: result.message
        });

      } catch (error) {
        console.error(`Failed to send notification via ${channelName}:`, error);
        results.push({
          channel: channelName,
          success: false,
          error: error.message
        });
      }
    }

    // Update notification status
    notification.status = results.some(r => r.success) ? 'SENT' : 'FAILED';
    notification.results = results;

    return results;
  }

  async sendEmailNotification(channel, notification) {
    // Email implementation would go here
    // For now, returning mock success
    console.log(`📧 Email notification sent: ${notification.alertName}`);
    return { success: true, message: 'Email sent successfully' };
  }

  async sendSMSNotification(channel, notification) {
    // SMS implementation would go here
    // For now, returning mock success
    console.log(`📱 SMS notification sent: ${notification.alertName}`);
    return { success: true, message: 'SMS sent successfully' };
  }

  async sendSlackNotification(channel, notification) {
    // Slack implementation would go here
    // For now, returning mock success
    console.log(`💬 Slack notification sent: ${notification.alertName}`);
    return { success: true, message: 'Slack message sent successfully' };
  }

  async sendDiscordNotification(channel, notification) {
    // Discord implementation would go here
    // For now, returning mock success
    console.log(`🎮 Discord notification sent: ${notification.alertName}`);
    return { success: true, message: 'Discord message sent successfully' };
  }

  async sendTelegramNotification(channel, notification) {
    // Telegram implementation would go here
    // For now, returning mock success
    console.log(`📞 Telegram notification sent: ${notification.alertName}`);
    return { success: true, message: 'Telegram message sent successfully' };
  }

  async sendWebSocketNotification(channel, notification) {
    // WebSocket implementation would go here
    this.emit('websocketNotification', notification);
    console.log(`🌐 WebSocket notification sent: ${notification.alertName}`);
    return { success: true, message: 'WebSocket notification sent successfully' };
  }

  /**
   * Alert Management
   */
  async enableAlert(alertId) {
    const alert = this.alerts.get(alertId);
    if (alert) {
      alert.enabled = true;
      console.log(`✅ Alert enabled: ${alert.name}`);
      return true;
    }
    return false;
  }

  async disableAlert(alertId) {
    const alert = this.alerts.get(alertId);
    if (alert) {
      alert.enabled = false;
      console.log(`❌ Alert disabled: ${alert.name}`);
      return true;
    }
    return false;
  }

  async snoozeAlert(alertId, duration) {
    const alert = this.alerts.get(alertId);
    if (alert) {
      alert.snoozeUntil = Date.now() + duration;
      console.log(`😴 Alert snoozed: ${alert.name} for ${duration}ms`);
      return true;
    }
    return false;
  }

  async deleteAlert(alertId) {
    const deleted = this.alerts.delete(alertId);
    if (deleted) {
      console.log(`🗑️ Alert deleted: ${alertId}`);
    }
    return deleted;
  }

  /**
   * Monitoring Loop
   */
  startMonitoring() {
    // Check alerts every 30 seconds
    setInterval(async () => {
      try {
        // This would be called with actual market data in a real implementation
        // For now, we'll just check system conditions
        const systemData = {
          exchangeConnections: [], // Would be populated with actual data
          aiModelErrors: 0
        };

        await this.checkAlertConditions({}, {}, systemData);
      } catch (error) {
        console.error('Error in alert monitoring loop:', error);
      }
    }, 30000); // 30 seconds
  }

  /**
   * Status and Analytics
   */
  getStatus() {
    return {
      isInitialized: this.isInitialized,
      totalAlerts: this.alerts.size,
      enabledAlerts: Array.from(this.alerts.values()).filter(a => a.enabled).length,
      totalNotifications: this.notifications.size,
      alertHistory: this.alertHistory.length,
      channels: Array.from(this.channels.keys()),
      lastAlert: this.alertHistory.length > 0 ? this.alertHistory[this.alertHistory.length - 1] : null
    };
  }

  getAlertAnalytics() {
    const alerts = Array.from(this.alerts.values());
    
    return {
      totalAlerts: alerts.length,
      byType: this.groupBy(alerts, 'type'),
      bySeverity: this.groupBy(alerts, 'severity'),
      mostTriggered: alerts.sort((a, b) => b.triggerCount - a.triggerCount).slice(0, 5),
      recentHistory: this.alertHistory.slice(-10)
    };
  }

  groupBy(array, key) {
    return array.reduce((groups, item) => {
      const group = item[key];
      groups[group] = groups[group] || [];
      groups[group].push(item);
      return groups;
    }, {});
  }
}

module.exports = AdvancedAlertSystem;