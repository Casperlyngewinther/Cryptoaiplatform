const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const WebSocket = require('ws');
const http = require('http');
const path = require('path');

// Import routes
const { router: authRoutes } = require('./routes/auth');
const tradingRoutes = require('./routes/trading');
const aiRoutes = require('./routes/ai');
const analyticsRoutes = require('./routes/analytics');
const securityRoutes = require('./routes/security');
const dashboardRoutes = require('./routes/dashboard');

// Import services
const DatabaseService = require('./services/DatabaseService');
const AIAgentService = require('./services/AIAgentService');
const TradingService = require('./services/TradingService');
const SecurityService = require('./services/SecurityService');
const WebSocketService = require('./services/WebSocketService');
const CryptoComExchange = require('./services/CryptoComExchange');

// Import V2.0 Enhanced Services
const CryptoAIPlatformV2 = require('./services/CryptoAIPlatformV2');
const QuantitativeEngine = require('./services/QuantitativeEngine');
const MasterAgentSystem = require('./services/MasterAgentSystem');
const ReinforcementLearningEngine = require('./services/ReinforcementLearningEngine');
const EnhancedOllamaGenerativeEngine = require('./services/EnhancedOllamaGenerativeEngine');
const OllamaHealthMonitor = require('./services/OllamaHealthMonitor');

// Import V2.1 Advanced Features
const AdvancedPortfolioEngine = require('./services/AdvancedPortfolioEngine');
const DeFiIntegrationEngine = require('./services/DeFiIntegrationEngine');
const AdvancedAlertSystem = require('./services/AdvancedAlertSystem');
const SocialTradingEngine = require('./services/SocialTradingEngine');
const AdvancedBacktestingEngine = require('./services/AdvancedBacktestingEngine');
const MobilePWAEngine = require('./services/MobilePWAEngine');
const NewsSentimentEngine = require('./services/NewsSentimentEngine');

// Import V3.0 Enterprise Services
const EnterpriseAIEngine = require('./services/EnterpriseAIEngine');
const BlockchainIntegrationEngine = require('./services/BlockchainIntegrationEngine');
const MicroservicesOrchestrator = require('./services/MicroservicesOrchestrator');
const EnterpriseSecurityEngine = require('./services/EnterpriseSecurityEngine');
const MultiTenantEngine = require('./services/MultiTenantEngine');
const StreamingAnalyticsEngine = require('./services/StreamingAnalyticsEngine');

// Import V4.0 Quantum & Advanced AI Era Services
const QuantumSecurityEngine = require('./services/QuantumSecurityEngine');
const AdvancedAIEngine = require('./services/AdvancedAIEngine');
const GlobalRegulatoryComplianceEngine = require('./services/GlobalRegulatoryComplianceEngine');
const InstitutionalTradingEngine = require('./services/InstitutionalTradingEngine');
const NextGenBlockchainEngine = require('./services/NextGenBlockchainEngine');
const PredictiveAnalyticsEngine = require('./services/PredictiveAnalyticsEngine');

// Import V5.0 100% Automated Era Services
const FullyAutonomousTradingEngine = require('./services/FullyAutonomousTradingEngine');
const SelfHealingInfrastructureEngine = require('./services/SelfHealingInfrastructureEngine');
const AutonomousRiskManagementEngine = require('./services/AutonomousRiskManagementEngine');
const IntelligentResourceOptimizationEngine = require('./services/IntelligentResourceOptimizationEngine');
const AutomatedComplianceReportingEngine = require('./services/AutomatedComplianceReportingEngine');
const SelfLearningMarketAdaptationEngine = require('./services/SelfLearningMarketAdaptationEngine');

// Import V5.0 Enhanced API Management & Trading Services
const APIKeyManager = require('./services/APIKeyManager');
const EnhancedAutomatedTradingEngine = require('./services/EnhancedAutomatedTradingEngine');

// Import V6.0 Next-Generation Intelligence Era Services
const NextGenAIIntelligenceEngine = require('./services/NextGenAIIntelligenceEngine');
const SocialTradingNetworkEngine = require('./services/SocialTradingNetworkEngine');
const CrossChainDeFiIntegrationEngine = require('./services/CrossChainDeFiIntegrationEngine');
const AdvancedAnalyticsDashboardEngine = require('./services/AdvancedAnalyticsDashboardEngine');

const app = express();
const server = http.createServer(app);

// Initialize WebSocket server
const wss = new WebSocket.Server({ server });
const wsService = new WebSocketService(wss);

// Middleware
app.use(helmet());
app.use(cors({
  origin: process.env.CLIENT_URL || 'http://localhost:3000',
  credentials: true
}));
app.use(morgan('combined'));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Initialize V2.0 Platform
let platformV2;
let ollamaHealthMonitor;

// Initialize V2.1 Advanced Features
let advancedPortfolioEngine;
let defiIntegrationEngine;
let advancedAlertSystem;
let socialTradingEngine;
let advancedBacktestingEngine;
let mobilePWAEngine;
let newsSentimentEngine;

// Initialize V3.0 Enterprise Services
let enterpriseAIEngine;
let blockchainIntegrationEngine;
let microservicesOrchestrator;
let enterpriseSecurityEngine;
let multiTenantEngine;
let streamingAnalyticsEngine;

// Initialize V4.0 Quantum & Advanced AI Era Services
let quantumSecurityEngine;
let advancedAIEngine;
let globalRegulatoryComplianceEngine;
let institutionalTradingEngine;
let nextGenBlockchainEngine;
let predictiveAnalyticsEngine;

// Initialize V5.0 100% Automated Era Services
let fullyAutonomousTradingEngine;
let selfHealingInfrastructureEngine;
let autonomousRiskManagementEngine;
let intelligentResourceOptimizationEngine;
let automatedComplianceReportingEngine;
let selfLearningMarketAdaptationEngine;

// Initialize V5.0 Enhanced Services
let apiKeyManager;
let enhancedAutomatedTradingEngine;

// Initialize V6.0 Next-Generation Intelligence Era Services
let nextGenAIIntelligenceEngine;
let socialTradingNetworkEngine;
let crossChainDeFiIntegrationEngine;
let advancedAnalyticsDashboardEngine;

// Initialize services
const initializeServices = async () => {
  try {
    // Legacy services initialization
    await DatabaseService.initialize();
    console.log('✅ Database Service initialized');
    
    await AIAgentService.initialize();
    console.log('✅ AI Agent Service initialized');
    
    await TradingService.initialize();
    console.log('✅ Trading Service initialized');
    
    await SecurityService.initialize();
    console.log('✅ Security Service initialized');
    
    // V2.0 Platform initialization
    console.log('🚀 Initializing CryptoAI Platform V2.0...');
    platformV2 = new CryptoAIPlatformV2();
    
    try {
      await platformV2.initialize();
      console.log('✅ CryptoAI Platform V2.0 initialized successfully');
      
      // Start the V2.0 platform
      await platformV2.start();
      console.log('🎯 V2.0 Self-evolving system active');
      
    } catch (v2Error) {
      console.warn('⚠️ V2.0 Platform initialization failed, running legacy mode:', v2Error.message);
      platformV2 = null;
    }

    // Initialize Advanced Features (V2.1)
    console.log('🚀 Initializing Advanced Features V2.1...');
    
    try {
      // Advanced Portfolio Analytics
      if (process.env.ENABLE_PORTFOLIO_ANALYTICS !== 'false') {
        advancedPortfolioEngine = new AdvancedPortfolioEngine();
        await advancedPortfolioEngine.initialize();
        console.log('📊 Advanced Portfolio Engine initialized');
      }

      // DeFi Integration
      if (process.env.ENABLE_DEFI_INTEGRATION !== 'false') {
        defiIntegrationEngine = new DeFiIntegrationEngine();
        await defiIntegrationEngine.initialize();
        console.log('🏦 DeFi Integration Engine initialized');
      }

      // Advanced Alert System
      if (process.env.ENABLE_ADVANCED_ALERTS !== 'false') {
        advancedAlertSystem = new AdvancedAlertSystem();
        await advancedAlertSystem.initialize();
        console.log('🚨 Advanced Alert System initialized');
      }

      // Social Trading Engine
      if (process.env.ENABLE_SOCIAL_TRADING !== 'false') {
        socialTradingEngine = new SocialTradingEngine();
        await socialTradingEngine.initialize();
        console.log('👥 Social Trading Engine initialized');
      }

      // Advanced Backtesting Engine
      if (process.env.ENABLE_BACKTESTING !== 'false') {
        advancedBacktestingEngine = new AdvancedBacktestingEngine();
        await advancedBacktestingEngine.initialize();
        console.log('🧪 Advanced Backtesting Engine initialized');
      }

      // Mobile & PWA Engine
      if (process.env.ENABLE_MOBILE_API !== 'false') {
        mobilePWAEngine = new MobilePWAEngine();
        await mobilePWAEngine.initialize();
        console.log('📱 Mobile & PWA Engine initialized');
      }

      // News & Sentiment Engine
      if (process.env.ENABLE_NEWS_SENTIMENT !== 'false') {
        newsSentimentEngine = new NewsSentimentEngine();
        await newsSentimentEngine.initialize();
        console.log('📰 News & Sentiment Engine initialized');
      }

      console.log('✅ All Advanced Features V2.1 initialized successfully');
      
    } catch (advancedError) {
      console.warn('⚠️ Some advanced features failed to initialize:', advancedError.message);
      console.log('💡 Platform will continue with available features');
    }

    // Initialize Enterprise Features (V3.0)
    console.log('🚀 Initializing Enterprise Features V3.0...');
    
    try {
      // Enterprise AI Engine
      if (process.env.FEATURE_AI_TRADING !== 'false') {
        enterpriseAIEngine = new EnterpriseAIEngine();
        await enterpriseAIEngine.initialize();
        console.log('🧠 Enterprise AI Engine initialized');
      }

      // Blockchain Integration Engine
      if (process.env.FEATURE_BLOCKCHAIN_INTEGRATION !== 'false') {
        blockchainIntegrationEngine = new BlockchainIntegrationEngine();
        await blockchainIntegrationEngine.initialize();
        console.log('⛓️ Blockchain Integration Engine initialized');
      }

      // Enterprise Security Engine
      if (process.env.FEATURE_ENTERPRISE_SECURITY !== 'false') {
        enterpriseSecurityEngine = new EnterpriseSecurityEngine();
        await enterpriseSecurityEngine.initialize();
        console.log('🔒 Enterprise Security Engine initialized');
      }

      // Multi-Tenant Engine
      if (process.env.FEATURE_MULTI_TENANT !== 'false') {
        multiTenantEngine = new MultiTenantEngine();
        await multiTenantEngine.initialize();
        console.log('🏢 Multi-Tenant Engine initialized');
      }

      // Streaming Analytics Engine
      if (process.env.FEATURE_STREAMING_ANALYTICS !== 'false') {
        streamingAnalyticsEngine = new StreamingAnalyticsEngine();
        await streamingAnalyticsEngine.initialize();
        console.log('🌊 Streaming Analytics Engine initialized');
      }

      // Microservices Orchestrator (Initialize last)
      if (process.env.FEATURE_MICROSERVICES !== 'false') {
        microservicesOrchestrator = new MicroservicesOrchestrator();
        await microservicesOrchestrator.initialize();
        console.log('🎭 Microservices Orchestrator initialized');
      }

      console.log('✅ All Enterprise Features V3.0 initialized successfully');
      
    } catch (enterpriseError) {
      console.warn('⚠️ Some enterprise features failed to initialize:', enterpriseError.message);
      console.log('💡 Platform will continue with available features');
    }

    // Initialize Quantum & Advanced AI Era Features (V4.0)
    console.log('🚀 Initializing Quantum & Advanced AI Era Features V4.0...');
    
    try {
      // Quantum Security Engine
      if (process.env.FEATURE_QUANTUM_SECURITY !== 'false') {
        quantumSecurityEngine = new QuantumSecurityEngine();
        await quantumSecurityEngine.initialize();
        console.log('🔮 Quantum Security Engine initialized');
      }

      // Advanced AI Engine
      if (process.env.FEATURE_ADVANCED_AI !== 'false') {
        advancedAIEngine = new AdvancedAIEngine();
        await advancedAIEngine.initialize();
        console.log('🧬 Advanced AI Engine initialized');
      }

      // Global Regulatory Compliance Engine
      if (process.env.FEATURE_GLOBAL_COMPLIANCE !== 'false') {
        globalRegulatoryComplianceEngine = new GlobalRegulatoryComplianceEngine();
        await globalRegulatoryComplianceEngine.initialize();
        console.log('🌍 Global Regulatory Compliance Engine initialized');
      }

      // Institutional Trading Engine
      if (process.env.FEATURE_INSTITUTIONAL_TRADING !== 'false') {
        institutionalTradingEngine = new InstitutionalTradingEngine();
        await institutionalTradingEngine.initialize();
        console.log('🏛️ Institutional Trading Engine initialized');
      }

      // Next-Generation Blockchain Engine
      if (process.env.FEATURE_NEXTGEN_BLOCKCHAIN !== 'false') {
        nextGenBlockchainEngine = new NextGenBlockchainEngine();
        await nextGenBlockchainEngine.initialize();
        console.log('⚡ Next-Generation Blockchain Engine initialized');
      }

      // Predictive Analytics Engine
      if (process.env.FEATURE_PREDICTIVE_ANALYTICS !== 'false') {
        predictiveAnalyticsEngine = new PredictiveAnalyticsEngine();
        await predictiveAnalyticsEngine.initialize();
        console.log('🔬 Predictive Analytics Engine initialized');
      }

      console.log('✅ All Quantum & Advanced AI Era Features V4.0 initialized successfully');
      
    } catch (quantumError) {
      console.warn('⚠️ Some V4.0 features failed to initialize:', quantumError.message);
      console.log('💡 Platform will continue with available features');
    }

    // Initialize 100% Automated Era Features (V5.0)
    console.log('🚀 Initializing 100% Automated Era Features V5.0...');
    
    try {
      // Fully Autonomous Trading Engine
      if (process.env.FEATURE_AUTONOMOUS_TRADING !== 'false') {
        fullyAutonomousTradingEngine = new FullyAutonomousTradingEngine();
        await fullyAutonomousTradingEngine.initialize();
        console.log('🤖 Fully Autonomous Trading Engine initialized');
      }

      // Self-Healing Infrastructure Engine
      if (process.env.FEATURE_SELF_HEALING !== 'false') {
        selfHealingInfrastructureEngine = new SelfHealingInfrastructureEngine();
        await selfHealingInfrastructureEngine.initialize();
        console.log('🔧 Self-Healing Infrastructure Engine initialized');
      }

      // Autonomous Risk Management Engine
      if (process.env.FEATURE_AUTONOMOUS_RISK !== 'false') {
        autonomousRiskManagementEngine = new AutonomousRiskManagementEngine();
        await autonomousRiskManagementEngine.initialize();
        console.log('⚖️ Autonomous Risk Management Engine initialized');
      }

      // Intelligent Resource Optimization Engine
      if (process.env.FEATURE_INTELLIGENT_OPTIMIZATION !== 'false') {
        intelligentResourceOptimizationEngine = new IntelligentResourceOptimizationEngine();
        await intelligentResourceOptimizationEngine.initialize();
        console.log('⚡ Intelligent Resource Optimization Engine initialized');
      }

      // Automated Compliance & Reporting Engine
      if (process.env.FEATURE_AUTOMATED_COMPLIANCE !== 'false') {
        automatedComplianceReportingEngine = new AutomatedComplianceReportingEngine();
        await automatedComplianceReportingEngine.initialize();
        console.log('📋 Automated Compliance & Reporting Engine initialized');
      }

      // Self-Learning Market Adaptation Engine
      if (process.env.FEATURE_SELF_LEARNING !== 'false') {
        selfLearningMarketAdaptationEngine = new SelfLearningMarketAdaptationEngine();
        await selfLearningMarketAdaptationEngine.initialize();
        console.log('🧠 Self-Learning Market Adaptation Engine initialized');
      }

      console.log('✅ All 100% Automated Era Features V5.0 initialized successfully');
      
    } catch (automatedError) {
      console.warn('⚠️ Some V5.0 features failed to initialize:', automatedError.message);
      console.log('💡 Platform will continue with available features');
    }

    // Initialize V5.0 Enhanced API Management & Trading
    console.log('🚀 Initializing Enhanced API Management & Trading V5.0...');
    
    try {
      // API Key Manager
      apiKeyManager = new APIKeyManager();
      console.log('🔑 API Key Manager initialized');

      // Enhanced Automated Trading Engine
      enhancedAutomatedTradingEngine = new EnhancedAutomatedTradingEngine();
      await enhancedAutomatedTradingEngine.start();
      console.log('🎯 Enhanced Automated Trading Engine started');

      console.log('✅ Enhanced API Management & Trading V5.0 initialized successfully');
      
    } catch (enhancedError) {
      console.warn('⚠️ Enhanced features failed to initialize:', enhancedError.message);
      console.log('💡 Platform will continue with available features');
    }

    // Initialize V6.0 Next-Generation Intelligence Era Features
    console.log('🚀 Initializing Next-Generation Intelligence Era Features V6.0...');
    
    try {
      // Next-Generation AI Intelligence Engine
      nextGenAIIntelligenceEngine = new NextGenAIIntelligenceEngine();
      await nextGenAIIntelligenceEngine.initialize();
      console.log('🧠 Next-Generation AI Intelligence Engine initialized');

      // Social Trading Network Engine
      socialTradingNetworkEngine = new SocialTradingNetworkEngine();
      await socialTradingNetworkEngine.initialize();
      console.log('👥 Social Trading Network Engine initialized');

      // Cross-Chain DeFi Integration Engine
      crossChainDeFiIntegrationEngine = new CrossChainDeFiIntegrationEngine();
      await crossChainDeFiIntegrationEngine.initialize();
      console.log('🌉 Cross-Chain DeFi Integration Engine initialized');

      // Advanced Analytics Dashboard Engine
      advancedAnalyticsDashboardEngine = new AdvancedAnalyticsDashboardEngine();
      await advancedAnalyticsDashboardEngine.initialize();
      console.log('📊 Advanced Analytics Dashboard Engine initialized');

      console.log('✅ All Next-Generation Intelligence Era Features V6.0 initialized successfully');
      
    } catch (nextGenError) {
      console.warn('⚠️ Some V6.0 features failed to initialize:', nextGenError.message);
      console.log('💡 Platform will continue with available features');
    }
    
    console.log('🚀 All services initialized successfully');
  } catch (error) {
    console.error('❌ Failed to initialize services:', error);
    process.exit(1);
  }
};

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/trading', tradingRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api/analytics', analyticsRoutes);
app.use('/api/security', securityRoutes);
app.use('/api/dashboard', dashboardRoutes);

// V5.0 Enhanced API Key Management Routes
app.get('/api/v5/api-keys/status', (req, res) => {
  try {
    const status = apiKeyManager ? apiKeyManager.getSystemStatus() : null;
    res.json({ success: true, status });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/v5/api-keys/exchanges', (req, res) => {
  try {
    const exchanges = apiKeyManager ? apiKeyManager.listConfiguredExchanges() : [];
    res.json({ success: true, exchanges });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/v5/trading/status', (req, res) => {
  try {
    const status = enhancedAutomatedTradingEngine ? enhancedAutomatedTradingEngine.getStatus() : null;
    res.json({ success: true, status });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/v5/trading/portfolio', (req, res) => {
  try {
    const portfolio = enhancedAutomatedTradingEngine ? enhancedAutomatedTradingEngine.getPortfolioSummary() : [];
    res.json({ success: true, portfolio });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/v5/trading/start', (req, res) => {
  try {
    if (enhancedAutomatedTradingEngine) {
      enhancedAutomatedTradingEngine.start();
      res.json({ success: true, message: 'Enhanced trading engine started' });
    } else {
      res.status(503).json({ success: false, error: 'Enhanced trading engine not available' });
    }
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/v5/trading/stop', (req, res) => {
  try {
    if (enhancedAutomatedTradingEngine) {
      enhancedAutomatedTradingEngine.stop();
      res.json({ success: true, message: 'Enhanced trading engine stopped' });
    } else {
      res.status(503).json({ success: false, error: 'Enhanced trading engine not available' });
    }
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// V6.0 Next-Generation Intelligence Era API Endpoints
app.get('/api/v6/ai/status', (req, res) => {
  try {
    const status = nextGenAIIntelligenceEngine ? nextGenAIIntelligenceEngine.getSystemStatus() : null;
    res.json({ success: true, status });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/v6/ai/predictions/:symbol', (req, res) => {
  try {
    const { symbol } = req.params;
    const { timeframe } = req.query;
    const predictions = nextGenAIIntelligenceEngine ? 
      nextGenAIIntelligenceEngine.getPredictions(symbol.toUpperCase(), timeframe) : null;
    res.json({ success: true, predictions });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/v6/ai/market-intelligence/:symbol', (req, res) => {
  try {
    const { symbol } = req.params;
    const intelligence = nextGenAIIntelligenceEngine ? 
      nextGenAIIntelligenceEngine.getMarketIntelligence(symbol.toUpperCase()) : null;
    res.json({ success: true, intelligence });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/v6/ai/sentiment', (req, res) => {
  try {
    const sentiment = nextGenAIIntelligenceEngine ? 
      nextGenAIIntelligenceEngine.getSentimentAnalysis() : null;
    res.json({ success: true, sentiment });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/v6/social/top-traders', (req, res) => {
  try {
    const { limit } = req.query;
    const traders = socialTradingNetworkEngine ? 
      socialTradingNetworkEngine.getTopTraders(parseInt(limit) || 10) : [];
    res.json({ success: true, traders });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/v6/social/trading-signals', (req, res) => {
  try {
    const { category, limit } = req.query;
    const signals = socialTradingNetworkEngine ? 
      socialTradingNetworkEngine.getTradingSignals(category, parseInt(limit) || 20) : [];
    res.json({ success: true, signals });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/v6/social/groups', (req, res) => {
  try {
    const { category } = req.query;
    const groups = socialTradingNetworkEngine ? 
      socialTradingNetworkEngine.getSocialGroups(category) : [];
    res.json({ success: true, groups });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/v6/social/community-insights/:asset', (req, res) => {
  try {
    const { asset } = req.params;
    const insights = socialTradingNetworkEngine ? 
      socialTradingNetworkEngine.getCommunityInsights(asset.toUpperCase()) : null;
    res.json({ success: true, insights });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/v6/defi/chains', (req, res) => {
  try {
    const chains = crossChainDeFiIntegrationEngine ? 
      crossChainDeFiIntegrationEngine.getSupportedChains() : {};
    res.json({ success: true, chains });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/v6/defi/yield-opportunities', (req, res) => {
  try {
    const { chain, minAPY } = req.query;
    const opportunities = crossChainDeFiIntegrationEngine ? 
      crossChainDeFiIntegrationEngine.getYieldOpportunities(chain, parseFloat(minAPY) || 0) : [];
    res.json({ success: true, opportunities });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/v6/defi/arbitrage', (req, res) => {
  try {
    const { minProfit } = req.query;
    const opportunities = crossChainDeFiIntegrationEngine ? 
      crossChainDeFiIntegrationEngine.getArbitrageOpportunities(parseFloat(minProfit) || 0) : [];
    res.json({ success: true, opportunities });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/v6/defi/portfolio', (req, res) => {
  try {
    const portfolio = crossChainDeFiIntegrationEngine ? 
      crossChainDeFiIntegrationEngine.getPortfolioStats() : {};
    res.json({ success: true, portfolio });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/v6/analytics/dashboard/:dashboardId', (req, res) => {
  try {
    const { dashboardId } = req.params;
    const { userId } = req.query;
    const dashboard = advancedAnalyticsDashboardEngine ? 
      advancedAnalyticsDashboardEngine.getDashboard(dashboardId, userId) : null;
    res.json({ success: true, dashboard });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/v6/analytics/data/:moduleId', (req, res) => {
  try {
    const { moduleId } = req.params;
    const { timeRange } = req.query;
    const data = advancedAnalyticsDashboardEngine ? 
      advancedAnalyticsDashboardEngine.getAnalyticsData(moduleId, timeRange) : null;
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/v6/analytics/alerts', (req, res) => {
  try {
    const { priority } = req.query;
    const alerts = advancedAnalyticsDashboardEngine ? 
      advancedAnalyticsDashboardEngine.getActiveAlerts(priority) : [];
    res.json({ success: true, alerts });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/v6/analytics/visualization/:vizId', (req, res) => {
  try {
    const { vizId } = req.params;
    const { config } = req.query;
    const visualization = advancedAnalyticsDashboardEngine ? 
      advancedAnalyticsDashboardEngine.getVisualization(vizId, config ? JSON.parse(config) : {}) : null;
    res.json({ success: true, visualization });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Mobile & PWA Routes
if (mobilePWAEngine) {
  app.use('/api', mobilePWAEngine.getRouter());
}

// Health check endpoint
app.get('/api/health', (req, res) => {
  const health = {
    status: 'healthy',
    timestamp: new Date().toISOString(),
    version: '6.0.0',
    services: {
      database: DatabaseService.isHealthy(),
      ai: AIAgentService.isHealthy(),
      trading: TradingService.isHealthy(),
      security: SecurityService.isHealthy()
    },
    advancedFeatures: {
      portfolioAnalytics: advancedPortfolioEngine ? advancedPortfolioEngine.getStatus() : null,
      defiIntegration: defiIntegrationEngine ? defiIntegrationEngine.getStatus() : null,
      advancedAlerts: advancedAlertSystem ? advancedAlertSystem.getStatus() : null,
      socialTrading: socialTradingEngine ? socialTradingEngine.getStatus() : null,
      backtesting: advancedBacktestingEngine ? advancedBacktestingEngine.getStatus() : null,
      mobilePWA: mobilePWAEngine ? mobilePWAEngine.getStatus() : null,
      newsSentiment: newsSentimentEngine ? newsSentimentEngine.getStatus() : null
    },
    enterpriseFeatures: {
      enterpriseAI: enterpriseAIEngine ? 'active' : 'inactive',
      blockchainIntegration: blockchainIntegrationEngine ? 'active' : 'inactive',
      microservices: microservicesOrchestrator ? 'active' : 'inactive',
      enterpriseSecurity: enterpriseSecurityEngine ? 'active' : 'inactive',
      multiTenant: multiTenantEngine ? 'active' : 'inactive',
      streamingAnalytics: streamingAnalyticsEngine ? 'active' : 'inactive'
    },
    quantumAIFeatures: {
      quantumSecurity: quantumSecurityEngine ? 'active' : 'inactive',
      advancedAI: advancedAIEngine ? 'active' : 'inactive',
      globalCompliance: globalRegulatoryComplianceEngine ? 'active' : 'inactive',
      institutionalTrading: institutionalTradingEngine ? 'active' : 'inactive',
      nextGenBlockchain: nextGenBlockchainEngine ? 'active' : 'inactive',
      predictiveAnalytics: predictiveAnalyticsEngine ? 'active' : 'inactive'
    },
    automatedEraFeatures: {
      fullyAutonomousTrading: fullyAutonomousTradingEngine ? 'active' : 'inactive',
      selfHealingInfrastructure: selfHealingInfrastructureEngine ? 'active' : 'inactive',
      autonomousRiskManagement: autonomousRiskManagementEngine ? 'active' : 'inactive',
      intelligentResourceOptimization: intelligentResourceOptimizationEngine ? 'active' : 'inactive',
      automatedCompliance: automatedComplianceReportingEngine ? 'active' : 'inactive',
      selfLearningAdaptation: selfLearningMarketAdaptationEngine ? 'active' : 'inactive'
    },
    enhancedV5Features: {
      apiKeyManager: apiKeyManager ? 'active' : 'inactive',
      enhancedAutomatedTrading: enhancedAutomatedTradingEngine ? (enhancedAutomatedTradingEngine.getStatus().isRunning ? 'running' : 'ready') : 'inactive'
    },
    nextGenV6Features: {
      aiIntelligenceEngine: nextGenAIIntelligenceEngine ? (nextGenAIIntelligenceEngine.getSystemStatus().isInitialized ? 'active' : 'initializing') : 'inactive',
      socialTradingNetwork: socialTradingNetworkEngine ? (socialTradingNetworkEngine.getSystemStatus().isInitialized ? 'active' : 'initializing') : 'inactive',
      crossChainDeFi: crossChainDeFiIntegrationEngine ? (crossChainDeFiIntegrationEngine.getSystemStatus().isInitialized ? 'active' : 'initializing') : 'inactive',
      advancedAnalytics: advancedAnalyticsDashboardEngine ? (advancedAnalyticsDashboardEngine.getSystemStatus().isInitialized ? 'active' : 'initializing') : 'inactive'
    }
  };

  // Add V2.0 status if available
  if (platformV2) {
    health.v2Platform = platformV2.getSystemStatus();
  }

  res.json(health);
});

// V2.0 API Endpoints
// V2.0 Trading decision endpoint
app.post('/api/v2/trading/decision', async (req, res) => {
  try {
    if (!platformV2) {
      return res.status(503).json({ error: 'V2.0 platform not available' });
    }
    
    const { marketData } = req.body;
    
    if (!marketData) {
      return res.status(400).json({ error: 'Market data required' });
    }

    const decision = await platformV2.makeTradingDecision(marketData);
    res.json({
      success: true,
      decision: decision,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('V2.0 trading decision error:', error);
    res.status(500).json({
      error: 'Trading decision failed',
      message: error.message
    });
  }
});

// V2.0 Execute trading decision
app.post('/api/v2/trading/execute', async (req, res) => {
  try {
    if (!platformV2) {
      return res.status(503).json({ error: 'V2.0 platform not available' });
    }
    
    const { decision } = req.body;
    
    if (!decision) {
      return res.status(400).json({ error: 'Decision required' });
    }

    const result = await platformV2.executeTradingDecision(decision);
    res.json({
      success: true,
      execution: result,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('V2.0 execution error:', error);
    res.status(500).json({
      error: 'Execution failed',
      message: error.message
    });
  }
});

// V2.0 System status
app.get('/api/v2/status', (req, res) => {
  try {
    if (!platformV2) {
      return res.status(503).json({ error: 'V2.0 platform not available' });
    }
    
    const status = platformV2.getSystemStatus();
    res.json({
      success: true,
      status: status,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    res.status(500).json({
      error: 'Status retrieval failed',
      message: error.message
    });
  }
});

// V2.0 Performance metrics
app.get('/api/v2/performance', async (req, res) => {
  try {
    if (!platformV2) {
      return res.status(503).json({ error: 'V2.0 platform not available' });
    }
    
    const performance = {
      quantitative: platformV2.quantEngine ? 'Available' : 'Not Available',
      reinforcementLearning: platformV2.rlEngine ? platformV2.rlEngine.getPerformanceReport() : 'Not Available',
      generativeAI: platformV2.ollamaEngine ? platformV2.ollamaEngine.getSystemStatus() : 'Not Available',
      timestamp: new Date().toISOString()
    };

    res.json({
      success: true,
      performance: performance
    });
  } catch (error) {
    res.status(500).json({
      error: 'Performance retrieval failed',
      message: error.message
    });
  }
});

// V2.0 Ollama AI explanations
app.post('/api/v2/ai/explain', async (req, res) => {
  try {
    if (!platformV2) {
      return res.status(503).json({ error: 'V2.0 platform not available' });
    }
    
    const { decision, marketContext, agentStates } = req.body;

    const explanation = await platformV2.ollamaEngine.explainTradingDecision(
      decision,
      marketContext,
      agentStates
    );

    res.json({
      success: true,
      explanation: explanation,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    res.status(500).json({
      error: 'AI explanation failed',
      message: error.message
    });
  }
});

// New Crypto.com Exchange API endpoints
app.get('/api/v2/exchange/cryptocom/status', (req, res) => {
  try {
    const status = TradingService.cryptoComExchange 
      ? TradingService.cryptoComExchange.getStatus()
      : { error: 'Exchange not initialized' };

    res.json({
      success: true,
      status: status,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to get exchange status',
      message: error.message
    });
  }
});

app.get('/api/v2/exchange/cryptocom/balance', async (req, res) => {
  try {
    if (!TradingService.cryptoComExchange) {
      return res.status(404).json({ error: 'Crypto.com exchange not initialized' });
    }

    const balance = await TradingService.cryptoComExchange.getBalance();
    
    res.json({
      success: true,
      balance: balance,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to get balance',
      message: error.message
    });
  }
});

app.get('/api/v2/exchange/cryptocom/market-data/:symbol?', (req, res) => {
  try {
    if (!TradingService.cryptoComExchange) {
      return res.status(404).json({ error: 'Crypto.com exchange not initialized' });
    }

    const { symbol } = req.params;
    const marketData = TradingService.cryptoComExchange.getMarketData(symbol);
    
    res.json({
      success: true,
      data: marketData,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to get market data',
      message: error.message
    });
  }
});

app.post('/api/v2/exchange/cryptocom/order', async (req, res) => {
  try {
    if (!TradingService.cryptoComExchange) {
      return res.status(404).json({ error: 'Crypto.com exchange not initialized' });
    }

    const { symbol, side, type, quantity, price } = req.body;
    
    if (!symbol || !side || !type || !quantity) {
      return res.status(400).json({ 
        error: 'Missing required parameters: symbol, side, type, quantity' 
      });
    }

    const orderParams = {
      symbol: symbol,
      side: side,
      type: type,
      quantity: parseFloat(quantity),
      ...(price && { price: parseFloat(price) })
    };

    const result = await TradingService.cryptoComExchange.placeOrder(orderParams);
    
    res.json({
      success: true,
      order: result,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    res.status(500).json({
      error: 'Order placement failed',
      message: error.message
    });
  }
});

// Enhanced All Exchanges API endpoints
app.get('/api/v2/exchange/all-real-data', async (req, res) => {
  try {
    const realBalances = await TradingService.getRealExchangeBalances();
    const realMarketData = await TradingService.getRealMarketData();
    const exchangeStatuses = TradingService.getExchangeStatus();
    const summary = TradingService.getConnectedExchangesSummary();
    
    res.json({
      success: true,
      data: {
        summary,
        exchanges: exchangeStatuses,
        balances: realBalances,
        marketData: realMarketData
      },
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to get real exchange data',
      message: error.message
    });
  }
});

// Generic exchange endpoints for all connected exchanges
app.get('/api/v2/exchange/:exchangeName/status', (req, res) => {
  try {
    const { exchangeName } = req.params;
    const exchange = TradingService.realExchanges.get(exchangeName);
    
    if (!exchange) {
      return res.status(404).json({ 
        error: `Exchange ${exchangeName} not connected`,
        availableExchanges: Array.from(TradingService.realExchanges.keys())
      });
    }

    const status = exchange.getStatus();
    
    res.json({
      success: true,
      exchange: exchangeName,
      status: status,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to get exchange status',
      message: error.message
    });
  }
});

app.get('/api/v2/exchange/:exchangeName/balance', async (req, res) => {
  try {
    const { exchangeName } = req.params;
    const exchange = TradingService.realExchanges.get(exchangeName);
    
    if (!exchange) {
      return res.status(404).json({ 
        error: `Exchange ${exchangeName} not connected`,
        availableExchanges: Array.from(TradingService.realExchanges.keys())
      });
    }

    if (!exchange.authenticated) {
      return res.status(401).json({ error: `Exchange ${exchangeName} not authenticated` });
    }

    const balance = await exchange.getBalances();
    
    res.json({
      success: true,
      exchange: exchangeName,
      balance: balance,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to get balance',
      message: error.message
    });
  }
});

app.get('/api/v2/exchange/:exchangeName/market-data/:symbol?', async (req, res) => {
  try {
    const { exchangeName, symbol } = req.params;
    const exchange = TradingService.realExchanges.get(exchangeName);
    
    if (!exchange) {
      return res.status(404).json({ 
        error: `Exchange ${exchangeName} not connected`,
        availableExchanges: Array.from(TradingService.realExchanges.keys())
      });
    }

    const marketData = await exchange.getMarketData(symbol || 'BTCUSDT');
    
    res.json({
      success: true,
      exchange: exchangeName,
      symbol: symbol || 'BTCUSDT',
      data: marketData,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to get market data',
      message: error.message
    });
  }
});

app.post('/api/v2/exchange/:exchangeName/order', async (req, res) => {
  try {
    const { exchangeName } = req.params;
    const { symbol, side, type, quantity, price } = req.body;

    if (!symbol || !side || !type || !quantity) {
      return res.status(400).json({
        error: 'Missing required parameters',
        required: ['symbol', 'side', 'type', 'quantity'],
        optional: ['price']
      });
    }

    const result = await TradingService.placeRealOrder(exchangeName, symbol, side, type, quantity, price);
    
    res.json({
      success: true,
      exchange: exchangeName,
      order: result,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to place order',
      message: error.message
    });
  }
});

app.get('/api/v2/exchange/:exchangeName/order/:symbol/:orderId', async (req, res) => {
  try {
    const { exchangeName, symbol, orderId } = req.params;

    const result = await TradingService.getOrderStatus(exchangeName, symbol, orderId);
    
    res.json({
      success: true,
      exchange: exchangeName,
      order: result,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to get order status',
      message: error.message
    });
  }
});

app.delete('/api/v2/exchange/:exchangeName/order/:symbol/:orderId', async (req, res) => {
  try {
    const { exchangeName, symbol, orderId } = req.params;

    const result = await TradingService.cancelOrder(exchangeName, symbol, orderId);
    
    res.json({
      success: true,
      exchange: exchangeName,
      result: result,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to cancel order',
      message: error.message
    });
  }
});

// Get all market data from all exchanges
app.get('/api/v2/exchange/all/market-data/:symbol?', async (req, res) => {
  try {
    const { symbol } = req.params;
    const marketData = await TradingService.getRealMarketData(symbol);
    
    res.json({
      success: true,
      symbol: symbol || 'all_major_pairs',
      data: marketData,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to get market data from exchanges',
      message: error.message
    });
  }
});

// Get summary of all connected exchanges
app.get('/api/v2/exchange/summary', (req, res) => {
  try {
    const summary = TradingService.getConnectedExchangesSummary();
    
    res.json({
      success: true,
      summary: summary,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    res.status(500).json({
      error: 'Failed to get exchange summary',
      message: error.message
    });
  }
});

// ===============================================
// Advanced Features V2.1 API Endpoints
// ===============================================

// Advanced Portfolio Analytics Endpoints
app.get('/api/v2/portfolio/analytics', async (req, res) => {
  try {
    if (!advancedPortfolioEngine) {
      return res.status(503).json({ error: 'Portfolio Analytics not available' });
    }
    
    // Mock portfolio data - replace with actual portfolio service
    const portfolioData = {
      positions: [
        { symbol: 'BTC', value: 15000, unrealizedPnL: 500 },
        { symbol: 'ETH', value: 8000, unrealizedPnL: -200 }
      ],
      totalValue: 23000
    };
    
    const analysis = await advancedPortfolioEngine.analyzePortfolio(portfolioData);
    res.json({
      success: true,
      data: analysis,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('Portfolio analytics error:', error);
    res.status(500).json({
      error: 'Portfolio analytics failed',
      message: error.message
    });
  }
});

// DeFi Integration Endpoints
app.get('/api/v2/defi/opportunities', async (req, res) => {
  try {
    if (!defiIntegrationEngine) {
      return res.status(503).json({ error: 'DeFi Integration not available' });
    }
    
    const { assets, riskTolerance = 'MEDIUM' } = req.query;
    const assetList = assets ? assets.split(',') : ['BTC', 'ETH', 'USDC'];
    
    const opportunities = await defiIntegrationEngine.discoverYieldOpportunities(assetList, riskTolerance);
    res.json({
      success: true,
      data: opportunities,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('DeFi opportunities error:', error);
    res.status(500).json({
      error: 'DeFi opportunities lookup failed',
      message: error.message
    });
  }
});

app.post('/api/v2/defi/execute', async (req, res) => {
  try {
    if (!defiIntegrationEngine) {
      return res.status(503).json({ error: 'DeFi Integration not available' });
    }
    
    const { opportunityId, amount, walletAddress } = req.body;
    
    if (!opportunityId || !amount || !walletAddress) {
      return res.status(400).json({ error: 'Missing required parameters' });
    }
    
    const result = await defiIntegrationEngine.executeDeFiStrategy(opportunityId, amount, walletAddress);
    res.json({
      success: true,
      data: result,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('DeFi execution error:', error);
    res.status(500).json({
      error: 'DeFi strategy execution failed',
      message: error.message
    });
  }
});

// Advanced Alert System Endpoints
app.post('/api/v2/alerts/create', async (req, res) => {
  try {
    if (!advancedAlertSystem) {
      return res.status(503).json({ error: 'Advanced Alerts not available' });
    }
    
    const alertConfig = req.body;
    const alertId = await advancedAlertSystem.createAlert(alertConfig);
    
    res.json({
      success: true,
      alertId: alertId,
      message: 'Alert created successfully',
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('Alert creation error:', error);
    res.status(500).json({
      error: 'Alert creation failed',
      message: error.message
    });
  }
});

app.get('/api/v2/alerts/analytics', async (req, res) => {
  try {
    if (!advancedAlertSystem) {
      return res.status(503).json({ error: 'Advanced Alerts not available' });
    }
    
    const analytics = advancedAlertSystem.getAlertAnalytics();
    res.json({
      success: true,
      data: analytics,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('Alert analytics error:', error);
    res.status(500).json({
      error: 'Alert analytics failed',
      message: error.message
    });
  }
});

// Social Trading Endpoints
app.post('/api/v2/social/trader/create', async (req, res) => {
  try {
    if (!socialTradingEngine) {
      return res.status(503).json({ error: 'Social Trading not available' });
    }
    
    const { userId, profileData } = req.body;
    const trader = await socialTradingEngine.createTraderProfile(userId, profileData);
    
    res.json({
      success: true,
      data: trader,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('Trader profile creation error:', error);
    res.status(500).json({
      error: 'Trader profile creation failed',
      message: error.message
    });
  }
});

app.get('/api/v2/social/leaderboard', async (req, res) => {
  try {
    if (!socialTradingEngine) {
      return res.status(503).json({ error: 'Social Trading not available' });
    }
    
    const { category = 'overall', limit = 20 } = req.query;
    
    res.json({
      success: true,
      data: socialTradingEngine.leaderboard[category]?.slice(0, limit) || [],
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('Leaderboard error:', error);
    res.status(500).json({
      error: 'Leaderboard fetch failed',
      message: error.message
    });
  }
});

app.post('/api/v2/social/copy-trading/start', async (req, res) => {
  try {
    if (!socialTradingEngine) {
      return res.status(503).json({ error: 'Social Trading not available' });
    }
    
    const { followerId, traderId, settings } = req.body;
    const copyTradeId = await socialTradingEngine.startCopyTrading(followerId, traderId, settings);
    
    res.json({
      success: true,
      copyTradeId: copyTradeId,
      message: 'Copy trading started successfully',
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('Copy trading start error:', error);
    res.status(500).json({
      error: 'Copy trading start failed',
      message: error.message
    });
  }
});

// Backtesting Endpoints
app.post('/api/v2/backtest/run', async (req, res) => {
  try {
    if (!advancedBacktestingEngine) {
      return res.status(503).json({ error: 'Backtesting Engine not available' });
    }
    
    const config = req.body;
    
    // Start backtest asynchronously
    const backtestPromise = advancedBacktestingEngine.runBacktest(config);
    
    // Return immediately with backtest ID
    res.json({
      success: true,
      message: 'Backtest started',
      backtestId: `backtest_${Date.now()}`,
      estimatedDuration: '2-5 minutes',
      timestamp: new Date().toISOString()
    });
    
    // Handle backtest completion asynchronously
    backtestPromise.catch(error => {
      console.error('Backtest error:', error);
    });
    
  } catch (error) {
    console.error('Backtest start error:', error);
    res.status(500).json({
      error: 'Backtest start failed',
      message: error.message
    });
  }
});

app.get('/api/v2/backtest/results/:backtestId', async (req, res) => {
  try {
    if (!advancedBacktestingEngine) {
      return res.status(503).json({ error: 'Backtesting Engine not available' });
    }
    
    const { backtestId } = req.params;
    const results = advancedBacktestingEngine.backtestResults.get(backtestId);
    
    if (!results) {
      return res.status(404).json({ error: 'Backtest results not found' });
    }
    
    res.json({
      success: true,
      data: results,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('Backtest results error:', error);
    res.status(500).json({
      error: 'Backtest results fetch failed',
      message: error.message
    });
  }
});

// News & Sentiment Endpoints
app.get('/api/v2/news/summary', async (req, res) => {
  try {
    if (!newsSentimentEngine) {
      return res.status(503).json({ error: 'News & Sentiment Engine not available' });
    }
    
    const { symbols, limit = 10 } = req.query;
    const symbolList = symbols ? symbols.split(',') : ['BTC', 'ETH'];
    
    const summary = newsSentimentEngine.getNewsSummary(symbolList, limit);
    res.json({
      success: true,
      data: summary,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('News summary error:', error);
    res.status(500).json({
      error: 'News summary fetch failed',
      message: error.message
    });
  }
});

app.get('/api/v2/sentiment/:symbol', async (req, res) => {
  try {
    if (!newsSentimentEngine) {
      return res.status(503).json({ error: 'News & Sentiment Engine not available' });
    }
    
    const { symbol } = req.params;
    const sentiment = newsSentimentEngine.getSentimentAnalysis(symbol.toUpperCase());
    
    if (!sentiment) {
      return res.status(404).json({ error: 'Sentiment data not found for symbol' });
    }
    
    res.json({
      success: true,
      data: sentiment,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('Sentiment analysis error:', error);
    res.status(500).json({
      error: 'Sentiment analysis failed',
      message: error.message
    });
  }
});

app.get('/api/v2/sentiment/market/overview', async (req, res) => {
  try {
    if (!newsSentimentEngine) {
      return res.status(503).json({ error: 'News & Sentiment Engine not available' });
    }
    
    const overview = newsSentimentEngine.getMarketSentimentOverview();
    res.json({
      success: true,
      data: overview,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('Market sentiment overview error:', error);
    res.status(500).json({
      error: 'Market sentiment overview failed',
      message: error.message
    });
  }
});

// Advanced Features Status Endpoint
app.get('/api/v2/features/status', async (req, res) => {
  try {
    const status = {
      version: '2.1.0',
      features: {
        portfolioAnalytics: {
          enabled: !!advancedPortfolioEngine,
          status: advancedPortfolioEngine ? advancedPortfolioEngine.getStatus() : null
        },
        defiIntegration: {
          enabled: !!defiIntegrationEngine,
          status: defiIntegrationEngine ? defiIntegrationEngine.getStatus() : null
        },
        advancedAlerts: {
          enabled: !!advancedAlertSystem,
          status: advancedAlertSystem ? advancedAlertSystem.getStatus() : null
        },
        socialTrading: {
          enabled: !!socialTradingEngine,
          status: socialTradingEngine ? socialTradingEngine.getStatus() : null
        },
        backtesting: {
          enabled: !!advancedBacktestingEngine,
          status: advancedBacktestingEngine ? advancedBacktestingEngine.getStatus() : null
        },
        mobilePWA: {
          enabled: !!mobilePWAEngine,
          status: mobilePWAEngine ? mobilePWAEngine.getStatus() : null
        },
        newsSentiment: {
          enabled: !!newsSentimentEngine,
          status: newsSentimentEngine ? newsSentimentEngine.getStatus() : null
        }
      },
      capabilities: {
        totalFeatures: 7,
        activeFeatures: [
          advancedPortfolioEngine,
          defiIntegrationEngine,
          advancedAlertSystem,
          socialTradingEngine,
          advancedBacktestingEngine,
          mobilePWAEngine,
          newsSentimentEngine
        ].filter(Boolean).length
      },
      timestamp: new Date().toISOString()
    };
    
    res.json({
      success: true,
      data: status,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('Features status error:', error);
    res.status(500).json({
      error: 'Features status check failed',
      message: error.message
    });
  }
});

// ===============================================
// End Advanced Features V2.1 API Endpoints
// ===============================================

// Serve static files in production
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, '../client/build')));
  
  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../client/build', 'index.html'));
  });
}

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(err.status || 500).json({
    error: {
      message: err.message || 'Internal Server Error',
      ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
    }
  });
});

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({
    error: {
      message: 'Resource not found'
    }
  });
});

const PORT = process.env.PORT || 5000;

// Start server
const startServer = async () => {
  await initializeServices();
  
  server.listen(PORT, () => {
    console.log(`🌟 CryptoAI Platform Server running on port ${PORT}`);
    console.log(`📊 WebSocket service active`);
    console.log(`🔒 Security service monitoring active`);
    console.log(`🤖 AI Agents operational`);
  });
};

startServer().catch(error => {
  console.error('Failed to start server:', error);
  process.exit(1);
});

module.exports = app;